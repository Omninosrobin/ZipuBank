package com.app.zipubank.models.Currency;

import java.io.Serializable;

public class Var implements Serializable {
    public double constant;

    public double getConstant() {
        return constant;
    }

    public void setConstant(double constant) {
        this.constant = constant;
    }
}
