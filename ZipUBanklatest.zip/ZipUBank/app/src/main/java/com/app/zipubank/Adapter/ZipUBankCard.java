package com.app.zipubank.Adapter;

import android.content.Context;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.zipubank.R;
import com.app.zipubank.models.CardDetailsClass;

import java.util.ArrayList;

public class ZipUBankCard extends RecyclerView.Adapter<ZipUBankCard.holder> {
    ArrayList<CardDetailsClass> cardDetailsRootArrayList;
    Context context;

    public ZipUBankCard(ArrayList<CardDetailsClass> cardDetailsRootArrayList, Context context) {
        this.cardDetailsRootArrayList = cardDetailsRootArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public ZipUBankCard.holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.atm_card, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ZipUBankCard.holder holder, int position) {



        holder.texta.setText(cardDetailsRootArrayList.get(position).getCardNumber());
        holder.textb.setText(cardDetailsRootArrayList.get(position).getCvv());
        holder.textc.setText(cardDetailsRootArrayList.get(position).getName());
        holder.textd.setText(cardDetailsRootArrayList.get(position).getExpiryMonth()+"/"+cardDetailsRootArrayList.get(position).getExpiryYear());
        //holder.years.setText();

    }

    @Override
    public int getItemCount() {
        return cardDetailsRootArrayList.size();
    }

    public class holder extends RecyclerView.ViewHolder {
        TextView texta, textb, textc, textd, years,slash;

        public holder(@NonNull View itemView) {
            super(itemView);
            texta = itemView.findViewById(R.id.txt1);
            textb = itemView.findViewById(R.id.txt4);
            textc = itemView.findViewById(R.id.txt5);
            textd = itemView.findViewById(R.id.txt6);
//            years = itemView.findViewById(R.id.txt8);
//            slash = itemView.findViewById(R.id.txt7);

        }
    }
}
