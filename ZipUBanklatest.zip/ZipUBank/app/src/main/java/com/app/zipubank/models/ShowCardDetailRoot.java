package com.app.zipubank.models;

import java.util.ArrayList;

public class ShowCardDetailRoot {
    public String status;
    public String mesage;
    public ArrayList<CardDetailsClass> details;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMesage() {
        return mesage;
    }

    public void setMesage(String mesage) {
        this.mesage = mesage;
    }

    public ArrayList<CardDetailsClass> getDetails() {
        return details;
    }

    public void setDetails(ArrayList<CardDetailsClass> details) {
        this.details = details;
    }
}
