package com.app.zipubank.HomeActivities.Profile.Category.FamilyAccount;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;

import com.app.zipubank.R;
import com.app.zipubank.databinding.FragmentVerifyNumberBinding;
import com.app.zipubank.models.OtpModel;
import com.app.zipubank.retrofit.Mvvm;
import com.app.zipubank.utils.App;
import com.app.zipubank.utils.AppConstants;
import com.bumptech.glide.Glide;

public class VerifyNumberFragment extends Fragment {
    FragmentVerifyNumberBinding fragmentVerifyNumberBinding;
    String phone;
    Bundle bundle;
    private Spinner simpleSpinner;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        fragmentVerifyNumberBinding = FragmentVerifyNumberBinding.inflate(getLayoutInflater());


        onClicks();


        Glide.with(requireContext()).load(CountryFragment.country_img).into(fragmentVerifyNumberBinding.imgCountry);
        fragmentVerifyNumberBinding.countryCode.setText(CountryFragment.country_code);

        return fragmentVerifyNumberBinding.getRoot();
    }

    private void onClicks() {

        fragmentVerifyNumberBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requireActivity().onBackPressed();
            }
        });


        fragmentVerifyNumberBinding.doneNumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                bundle = new Bundle();
                phone = fragmentVerifyNumberBinding.enterNumber.getText().toString();
                bundle.putString("phone", phone);

                if (phone.isEmpty()) {
                    fragmentVerifyNumberBinding.enterNumber.setError("Enter your mobile number");
                } else {
                    App.getSingleton().setPhone(phone);
                    signUpUser();
                }

            }
        });
    }

    private void signUpUser() {
        new Mvvm().otpModelLiveData(requireActivity(),phone).observe(requireActivity(), new Observer<OtpModel>() {
            @Override
            public void onChanged(OtpModel otpModel) {

                if (otpModel.getSuccess().equalsIgnoreCase("1")) {
                    Navigation.findNavController(fragmentVerifyNumberBinding.getRoot()).navigate(R.id.SMSFragment2, bundle);

                    App.getAppPreference().saveStringValue(AppConstants.PHONE_NUMBER, CountryFragment.country_code  + "" + phone);

                    App.getAppPreference().saveStringValue(AppConstants.OTP, otpModel.getOtp());

                    Toast.makeText(getActivity(), "" + otpModel.getMessage(), Toast.LENGTH_SHORT).show();
                } else {

                    Toast.makeText(getActivity(), "" + otpModel.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

        });

    }


}