package com.app.zipubank.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.zipubank.R;
import com.app.zipubank.models.BankListClass;
import com.bumptech.glide.Glide;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class BankListAdapter extends RecyclerView.Adapter<BankListAdapter.ViewHolder> {
    ArrayList<BankListClass> bankList;
    CallbackClick callbackClick;
    Context context;

    public interface CallbackClick{
        void onClick(int position);
    }

    public BankListAdapter(ArrayList<BankListClass> bankList, CallbackClick callbackClick, Context context) {
        this.bankList = bankList;
        this.callbackClick = callbackClick;
        this.context = context;
    }

    @NonNull
    @Override
    public BankListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.select_bank_list,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull BankListAdapter.ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        Glide.with(context).load(bankList.get(position).getBankImage()).placeholder(R.drawable.bank_one).into(holder.image);
        holder.name_of_bank.setText(bankList.get(position).getBankName());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                callbackClick.onClick(position);
            }
        });
    }
    @Override
    public int getItemCount() {
        return bankList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView image;
        private TextView name_of_bank;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.image);
            name_of_bank = itemView.findViewById(R.id.name_of_bank);
        }
    }
}
