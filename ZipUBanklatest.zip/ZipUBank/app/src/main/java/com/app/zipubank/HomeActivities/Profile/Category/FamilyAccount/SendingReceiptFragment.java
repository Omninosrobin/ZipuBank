package com.app.zipubank.HomeActivities.Profile.Category.FamilyAccount;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;

import com.app.zipubank.Adapter.AdapterRecieverData;
import com.app.zipubank.R;
import com.app.zipubank.databinding.FragmentSendingReceiptBinding;
import com.app.zipubank.models.GetMyBankDetail;
import com.app.zipubank.models.Receipt.ReceiptClass;
import com.app.zipubank.models.Receipt.SomeoneElse.SomeoneElseGetRoot;
import com.app.zipubank.retrofit.Mvvm;
import com.app.zipubank.utils.App;
import com.app.zipubank.utils.CommonUtil;
import org.jetbrains.annotations.NotNull;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class SendingReceiptFragment extends Fragment implements AdapterRecieverData.Callback,Serializable{
    FragmentSendingReceiptBinding fragmentSendingReceiptBinding;
    private ArrayList<String> list;
    private ArrayList<ReceiptClass> myself_receipt_list;
    private List<GetMyBankDetail.Detail> someone_else_receipt_list;
    private ArrayList<ReceiptClass> business_receipt_list;

    List<SomeoneElseGetRoot.Detail> data;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        fragmentSendingReceiptBinding = FragmentSendingReceiptBinding.inflate(getLayoutInflater());
        return fragmentSendingReceiptBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        setData();

        list = new ArrayList<>();

        setSpinnerAdapter(list);
        someone_else_receipt_list = new ArrayList<>();

//        new Mvvm().getSomeoneRootLiveData(requireActivity(), "15").observe(requireActivity(), new Observer<SomeoneElseGetRoot>() {
//            @Override
//            public void onChanged(SomeoneElseGetRoot someoneElseGetRoot) {
//                if (someoneElseGetRoot.getStatus().equals("1")){
//                    Toast.makeText(requireContext(), "1"+someoneElseGetRoot.getMessage(), Toast.LENGTH_SHORT).show();
//                    someone_else_receipt_list= someoneElseGetRoot.getDetails();
//                    receiptAdapter = new ReceiptAdapter(someone_else_receipt_list);
//                    fragmentSendingReceiptBinding.receiptRecyclerView.setAdapter(receiptAdapter);
//                }
//                else{
//                    Toast.makeText(requireContext(), "2"+someoneElseGetRoot.getMessage(), Toast.LENGTH_SHORT).show();
//                }
//            }
//        });

  //      getAdapter();
        fragmentSendingReceiptBinding.addARecipient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(requireActivity(), R.id.nav_home).navigate(R.id.action_sendingReceiptFragment_to_addARecipient);
            }
        });
    }

    private void setData() {
        new Mvvm().getSomeoneRootLiveData(requireActivity(),CommonUtil.getUserId()).observe(requireActivity(), new Observer<SomeoneElseGetRoot>() {
            @Override
            public void onChanged(SomeoneElseGetRoot someoneElseGetRoot) {

                SendMoney.bankUserData=someoneElseGetRoot;

               data =someoneElseGetRoot.getDetails();
                App.getAppPreference().saveModel("userBankdata",someoneElseGetRoot.getDetails());


                AdapterRecieverData adapterRecieverData=new AdapterRecieverData(data,requireContext(),SendingReceiptFragment.this);
                fragmentSendingReceiptBinding.myselfBankDetails.setAdapter(adapterRecieverData);
            }
        });


    }

//    private void getAdapter() {
//        new Mvvm().getAddMyBankAccountLive(requireActivity(), CommonUtil.getUserId()).observe(requireActivity(), new Observer<GetMyBankDetail>() {
//            @Override
//            public void onChanged(GetMyBankDetail getMyBankDetail) {
//                if (getMyBankDetail.getSuccess().equalsIgnoreCase("1")){
//
//                    fragmentSendingReceiptBinding.emptyText.setVisibility(View.GONE);
//                    fragmentSendingReceiptBinding.myselfBankDetails.setVisibility(View.VISIBLE);
//
//                    someone_else_receipt_list = getMyBankDetail.getDetails();
//                    MyselfAccuntDetailsAdapter myselfAccuntDetailsAdapter = new MyselfAccuntDetailsAdapter(someone_else_receipt_list);
//                    fragmentSendingReceiptBinding.myselfBankDetails.setAdapter(myselfAccuntDetailsAdapter);
//
//                    Toast.makeText(requireContext(), ""+getMyBankDetail.getMessage(), Toast.LENGTH_SHORT).show();
//                }
//                else{
//                    fragmentSendingReceiptBinding.emptyText.setVisibility(View.VISIBLE);
//                    fragmentSendingReceiptBinding.myselfBankDetails.setVisibility(View.GONE);
//                    Toast.makeText(requireContext(), ""+getMyBankDetail.getMessage(), Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
//    }

    private void setSpinnerAdapter(ArrayList<String> list) {
        list.add("Myself");
        list.add("Someone Else");
        list.add("Business");

        ArrayAdapter<String> adp2 = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, list);
        adp2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fragmentSendingReceiptBinding.selectReceipt.setAdapter(adp2);
        fragmentSendingReceiptBinding.selectReceipt.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0) {
                    Toast.makeText(requireContext(), ""+fragmentSendingReceiptBinding.selectReceipt.getSelectedItem(), Toast.LENGTH_SHORT).show();
                } else if (i == 1) {
                    Toast.makeText(requireContext(), ""+fragmentSendingReceiptBinding.selectReceipt.getSelectedItem(), Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(requireContext(), ""+fragmentSendingReceiptBinding.selectReceipt.getSelectedItem(), Toast.LENGTH_SHORT).show();
                }
                fragmentSendingReceiptBinding.selectReceipt.setSelection(i);
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
    }

    @Override
    public void callback(SomeoneElseGetRoot.Detail bankData) {
        if (bankData!=null){
          SendMoney.detail=bankData;
            Navigation.findNavController(requireActivity(), R.id.nav_home).navigate(R.id.action_sendingReceiptFragment_to_internationalLocalFragment);

        }else{

        }
    }
}