package com.app.zipubank.HomeActivities.Home.PayByCard;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;

import com.app.zipubank.Adapter.CardListAdapter;
import com.app.zipubank.HomeActivities.Home.AddMoney.AddMoneyFragment;
import com.app.zipubank.HomeActivities.Home.ChooseAccount.ChooseAnAccountFragment;
import com.app.zipubank.R;

import com.app.zipubank.databinding.FragmentPayByCardBinding;
import com.app.zipubank.models.CardDetailsClass;
import com.app.zipubank.models.ShowCardDetailRoot;
import com.app.zipubank.retrofit.Mvvm;
import com.app.zipubank.utils.CommonUtil;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Map;

public class PayByCardFragment extends Fragment {
    FragmentPayByCardBinding fragmentPayByCardBinding;
    ArrayList<CardDetailsClass> cardDetailsRootArrayList = new ArrayList<>();
    CardListAdapter cardListAdapter;
    private String getTagRelative;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        fragmentPayByCardBinding = FragmentPayByCardBinding.inflate(getLayoutInflater());
        return fragmentPayByCardBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        new Mvvm().getCardDetailsRootLiveData(requireActivity(), CommonUtil.getUserId()).observe(requireActivity(), new Observer<ShowCardDetailRoot>() {
            @Override
            public void onChanged(ShowCardDetailRoot showCardDetailRoot) {
                if (showCardDetailRoot.getStatus().equals("1")) {
                    cardDetailsRootArrayList = showCardDetailRoot.getDetails();
                    cardListAdapter = new CardListAdapter(cardDetailsRootArrayList, new CardListAdapter.Callback() {
                        @Override
                        public void deleteList(int position) {

                            new Mvvm().removeCardRootLiveData(requireActivity(), CommonUtil.getUserId(),
                                    showCardDetailRoot.getDetails().get(position).getId()).observe(requireActivity(), new Observer<Map>() {
                                @Override
                                public void onChanged(Map map) {
                                    if (map.get("status").equals("1")) {
                                        Toast.makeText(requireContext(), "" + map.get("message"), Toast.LENGTH_SHORT).show();
                                    } else {
                                        Toast.makeText(requireContext(), "" + map.get("message"), Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                            cardDetailsRootArrayList.remove(position);
                            cardListAdapter.notifyDataSetChanged();
                        }

                        @Override
                        public void selectList(RelativeLayout selectList, String tag) {
                            selectList.setTag("1");
                            if (selectList.getTag().equals("0")) {
                                selectList.setBackgroundResource(R.drawable.full_round);
                                selectList.setTag("1");
                            } else {
                                selectList.setBackgroundResource(R.drawable.blue_round);
                                selectList.setTag("0");
                            }
                            getTagRelative = tag;
                        }


                    });
                    fragmentPayByCardBinding.cardVisaListRecycler.setAdapter(cardListAdapter);
                    Toast.makeText(requireContext(), "" + showCardDetailRoot.getMesage(), Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(requireActivity(), "" + showCardDetailRoot.getMesage(), Toast.LENGTH_SHORT).show();
                }
            }
        });

        fragmentPayByCardBinding.selectCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(requireActivity(), R.id.nav_home).navigate(R.id.action_payByCardFragment_to_byCardPaymentFragment);
            }
        });

        fragmentPayByCardBinding.letsGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ChooseAnAccountFragment.type == null) {
                    Toast.makeText(requireContext(), "Select your type", Toast.LENGTH_SHORT).show();
                }
                else if (cardDetailsRootArrayList.size()==0){
                    Toast.makeText(requireContext(), "Add Card", Toast.LENGTH_SHORT).show();
                }
                else if (getTagRelative==null) {
                    Toast.makeText(requireContext(), "Select the card", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(requireContext(), " id :   "+ AddMoneyFragment.amount, Toast.LENGTH_SHORT).show();
                        new Mvvm().addAmountLiveData(requireActivity(), CommonUtil.getUserId(), AddMoneyFragment.wallet_id,
                                AddMoneyFragment.amount, ChooseAnAccountFragment.type).observe(requireActivity(), new Observer<Map>() {
                            @Override
                            public void onChanged(Map map) {
                                if (map.get("status").equals("1")) {
                                    Toast.makeText(requireContext(), "" + map.get("message"), Toast.LENGTH_SHORT).show();
                                    Navigation.findNavController(requireActivity(), R.id.nav_home).navigate(R.id.homeFragment);
                                } else {
                                    Toast.makeText(requireContext(), "" + map.get("message"), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }
                }
        });
    }
}