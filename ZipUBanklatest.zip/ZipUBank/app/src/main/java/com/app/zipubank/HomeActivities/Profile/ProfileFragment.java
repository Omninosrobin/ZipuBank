package com.app.zipubank.HomeActivities.Profile;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.app.zipubank.MainActivity;
import com.app.zipubank.R;
import com.app.zipubank.databinding.FragmentProfileBinding;
import com.app.zipubank.databinding.LogoutDialogBinding;
import com.app.zipubank.models.LogoutModel;
import com.app.zipubank.models.RegisterModel;
import com.app.zipubank.retrofit.Mvvm;
import com.app.zipubank.utils.App;
import com.app.zipubank.utils.AppConstants;
import com.app.zipubank.utils.CommonUtil;
import com.bumptech.glide.Glide;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;


public class ProfileFragment extends Fragment {

    FragmentProfileBinding binding;
    private String userId="";
    private String email="";
    private   String name="";
    private   String image="";
    private RegisterModel details;
    AlertDialog alertDialog;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        Toast.makeText(requireActivity(), "This.USer"+CommonUtil.getUserId(), Toast.LENGTH_SHORT).show();
        binding = binding.inflate(getLayoutInflater());

        details = App.getAppPreference().getModel(AppConstants.USER_DETAILS, RegisterModel.class);
        userId= details.getDetails().getId();
        email= details.getDetails().getEmail();
        image=details.getDetails().getProfileImage();
     //   Toast.makeText(requireContext(), ""+email, Toast.LENGTH_SHORT).show();
        name= details.getDetails().getName();
//        Toast.makeText(requireContext(), ""+details.getDetails().getName(), Toast.LENGTH_SHORT).show();
//        Toast.makeText(requireContext(), ""+details.getDetails().getProfileImage(), Toast.LENGTH_SHORT).show();
//        Toast.makeText(requireContext(), ""+email, Toast.LENGTH_SHORT).show();

        onClicks();
        setData();
        return binding.getRoot();
    }

    private void setData() {
        if (details.getDetails().getName() != null) {
            binding.userName.setText(name);
            binding.email.setText(email);
        } else {
            Toast.makeText(requireContext(), " null", Toast.LENGTH_SHORT).show();
        }
        if (details.getDetails().getProfileImage() != null && details.getDetails().getProfileImage().length() != 0) {
   //         Toast.makeText(requireActivity(), "Image 1"+details.getDetails().getProfileImage(), Toast.LENGTH_SHORT).show();
            Glide.with(requireContext()).load(details.getDetails().getProfileImage()).placeholder(R.drawable.user_new).into(binding.imageProfile);
//

        }

    }
    private void onClicks() {
        binding.logout.setOnClickListener(view -> {
            if (alertDialog != null) {
                alertDialog.dismiss();
            }

            final AlertDialog.Builder alert = new AlertDialog.Builder(requireActivity());
            LogoutDialogBinding dialogKickoutJoinedUserBinding = LogoutDialogBinding.inflate(LayoutInflater.from(requireActivity()));
            alert.setView(dialogKickoutJoinedUserBinding.getRoot());
            alertDialog = alert.create();
            alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

            dialogKickoutJoinedUserBinding.logoutBtn.setOnClickListener(view1 -> {

                logoutUser();

            });

            dialogKickoutJoinedUserBinding.cancelBtn.setOnClickListener(view1 -> {

                alertDialog.dismiss();

            });

            alertDialog.show();

        });

        binding.editProfile.setOnClickListener(view -> {

            Navigation.findNavController(binding.getRoot()).navigate(R.id.action_profileFragment_to_editProfileFragment);
        });

        binding.bankGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(binding.getRoot()).navigate(R.id.action_profileFragment_to_viewBankDetail2);

            }
        });
      //  binding.profileNext.setOnClickListener(view -> Navigation.findNavController(binding.getRoot()).navigate(R.id.action_profileFragment_to_kindOfAccount));
    }

    private void logoutUser() {
        new Mvvm().logoutUser(getActivity(),userId).observe(getActivity(), map -> {
            if (map.getSuccess().equalsIgnoreCase("1")){

                App.getAppPreference().clearPreferences();
                startActivity(new Intent(getActivity(), MainActivity.class));
                getActivity().finish();

             //   Toast.makeText(getActivity(), map.getSuccess(), Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(getActivity(), map.getSuccess(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        requireActivity().findViewById(R.id.bottom_nav).setVisibility(View.VISIBLE);
    }
}