package com.app.zipubank.BaseFragments.selectionScreenFragment;

import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.app.zipubank.R;
import com.app.zipubank.databinding.FragmentSelectionScreenBinding;
import com.app.zipubank.models.SliderData;
import com.smarteist.autoimageslider.SliderView;

import java.util.ArrayList;

public class SelectionScreen extends Fragment {

    FragmentSelectionScreenBinding binding;

    String url1 = "https://firebasestorage.googleapis.com/v0/b/healthkangaroouser.appspot.com/o/00000000.jpg?alt=media&token=b23c6a84-bf3e-4328-9c3c-fc4f89383609";
    String url2 = "https://firebasestorage.googleapis.com/v0/b/healthkangaroouser.appspot.com/o/00000000.jpg?alt=media&token=b23c6a84-bf3e-4328-9c3c-fc4f89383609";
    String url3 = "https://firebasestorage.googleapis.com/v0/b/healthkangaroouser.appspot.com/o/00000000.jpg?alt=media&token=b23c6a84-bf3e-4328-9c3c-fc4f89383609";
    String url4 = "https://firebasestorage.googleapis.com/v0/b/healthkangaroouser.appspot.com/o/00000000.jpg?alt=media&token=b23c6a84-bf3e-4328-9c3c-fc4f89383609";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding=FragmentSelectionScreenBinding.inflate(getLayoutInflater());

        onClicks();
        sliderImage();

        return binding.getRoot();
    }

    private void onClicks() {
        binding.loginBtn.setOnClickListener(view -> {

            Navigation.findNavController(binding.getRoot()).navigate(R.id.action_selectionScreen_to_loginScreen);

            binding.signUpBtn.setBackgroundResource(R.drawable.white_button);
            binding.loginBtn.setBackgroundResource(R.drawable.blue_button);
        });


        binding.signUpBtn.setOnClickListener(v ->
        {
            Navigation.findNavController(binding.getRoot()).navigate(R.id.enterEmailFragment2);

            binding.signUpBtn.setBackgroundResource(R.drawable.blue_button);
            binding.loginBtn.setBackgroundResource(R.drawable.white_button);
        });


    }

    private void sliderImage() {

        ArrayList<SliderData> sliderDataArrayList = new ArrayList<>();
        sliderDataArrayList.add(new SliderData(url1));
        sliderDataArrayList.add(new SliderData(url2));
        sliderDataArrayList.add(new SliderData(url3));
        sliderDataArrayList.add(new SliderData(url4));
//        SliderAdapter adapter = new SliderAdapter(requireContext(), sliderDataArrayList);
//        binding.slider.setAutoCycleDirection(SliderView.LAYOUT_DIRECTION_LTR);
//        binding.slider.setSliderAdapter(adapter);
//        binding.slider.setScrollTimeInSec(4);
//        binding.slider.setAutoCycle(true);
//        binding.slider.startAutoCycle();
    }
}