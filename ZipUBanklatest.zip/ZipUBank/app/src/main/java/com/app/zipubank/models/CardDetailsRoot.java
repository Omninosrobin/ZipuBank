package com.app.zipubank.models;

import java.io.Serializable;
import java.util.ArrayList;

public class CardDetailsRoot implements Serializable {
    public String status;
    public String mesage;
    public CardDetailsClass details;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMesage() {
        return mesage;
    }

    public void setMesage(String mesage) {
        this.mesage = mesage;
    }

    public CardDetailsClass getDetails() {
        return details;
    }

    public void setDetails(CardDetailsClass details) {
        this.details = details;
    }
}
