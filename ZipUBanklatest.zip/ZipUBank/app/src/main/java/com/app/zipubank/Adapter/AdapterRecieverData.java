package com.app.zipubank.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.zipubank.HomeActivities.Profile.Category.FamilyAccount.UnMatchedContacts;
import com.app.zipubank.R;
import com.app.zipubank.models.Receipt.SomeoneElse.SomeoneElseGetRoot;

import java.util.List;

public class AdapterRecieverData extends RecyclerView.Adapter<AdapterRecieverData.holder> {
List<SomeoneElseGetRoot.Detail> list;
Context context;
Callback callback;

    public AdapterRecieverData(List<SomeoneElseGetRoot.Detail> list, Context context, Callback callback) {
        this.list = list;
        this.context = context;
        this.callback = callback;
    }

    @NonNull
    @Override
    public AdapterRecieverData.holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.reciever_data,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterRecieverData.holder holder, @SuppressLint("RecyclerView") int position) {
        holder.name.setText(list.get(position).getHolderAccountName());
        holder.accountNumber.setText(list.get(position).getBankAccopuntNumber());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callback.callback(list.get(position));
            }
        });

    }

    @Override
    public int getItemCount() {
        if (list!=null){
            return list.size();
        }else {
            return 0;
        }

    }

    public interface Callback {

        void callback(SomeoneElseGetRoot.Detail detail);
    }

    public class holder extends RecyclerView.ViewHolder {
        TextView name,accountNumber;
        public holder(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.holderRecName);
            accountNumber=itemView.findViewById(R.id.RecieverAcc_number);

        }
    }

}
