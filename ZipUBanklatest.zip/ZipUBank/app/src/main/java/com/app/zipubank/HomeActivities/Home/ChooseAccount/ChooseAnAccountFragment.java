package com.app.zipubank.HomeActivities.Home.ChooseAccount;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Toast;

import com.app.zipubank.R;
import com.app.zipubank.databinding.FragmentChooseAnAccountBinding;
import com.app.zipubank.retrofit.Mvvm;
import com.app.zipubank.utils.CommonUtil;

import org.jetbrains.annotations.NotNull;

import java.util.Map;

public class ChooseAnAccountFragment extends Fragment {
FragmentChooseAnAccountBinding fragmentChooseAnAccountBinding;
public static String type = null;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        fragmentChooseAnAccountBinding = FragmentChooseAnAccountBinding.inflate(getLayoutInflater());
        return fragmentChooseAnAccountBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        fragmentChooseAnAccountBinding.pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                type="1";
                final Dialog dialog = new Dialog(requireContext());
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setContentView(R.layout.choose_apple_list);
                dialog.setCanceledOnTouchOutside(true);
                dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.getWindow().setGravity(Gravity.BOTTOM);
                dialog.show();
            }
        });

        fragmentChooseAnAccountBinding.chooseBankAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                type="0";
         //       Navigation.findNavController(requireActivity(),R.id.nav_home).navigate(R.id.action_chooseAnAccountFragment_to_selectBankFragment);
         //       Navigation.findNavController(requireActivity(),R.id.nav_home).navigate(R.id.action_chooseAnAccountFragment_to_addUserBank);

            }
        });

        fragmentChooseAnAccountBinding.debitCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                type="2";
                Navigation.findNavController(requireActivity(),R.id.nav_home).navigate(R.id.action_chooseAnAccountFragment_to_payByCardFragment);
            }
        });

        fragmentChooseAnAccountBinding.cofirmAddMoney.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }
}