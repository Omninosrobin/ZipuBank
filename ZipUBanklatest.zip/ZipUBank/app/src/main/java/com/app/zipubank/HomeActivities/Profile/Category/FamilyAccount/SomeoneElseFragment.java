package com.app.zipubank.HomeActivities.Profile.Category.FamilyAccount;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.app.zipubank.R;

import com.app.zipubank.databinding.FragmentSomeoneElseBinding;
import com.app.zipubank.models.Receipt.SomeoneElse.SomeoneElseRoot;
import com.app.zipubank.retrofit.Mvvm;
import com.app.zipubank.utils.App;
import com.app.zipubank.utils.CommonUtil;

import org.jetbrains.annotations.NotNull;


public class SomeoneElseFragment extends Fragment {
FragmentSomeoneElseBinding binding;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentSomeoneElseBinding.inflate(getLayoutInflater());
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.doneSomeOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                recieptApi();
            }
        });

    }

    private void recieptApi() {
        String email = binding.enterEmail.getText().toString();
        String name = binding.enterHolderName.getText().toString();
        String iban = binding.enterIban.getText().toString();
        String country = binding.enterCountry.getText().toString();
        String city = binding.enterCity.getText().toString();
        String address = binding.enterAddress.getText().toString();
        String zipcode = binding.enterZipCode.getText().toString();

        if (email.length()==0){
            binding.enterEmail.setError("Enter Email");
            binding.enterEmail.requestFocus();
        }
        else if (name.length()==0){
            binding.enterHolderName.setError("Enter card holder name");
            binding.enterHolderName.requestFocus();
        }
         else if (iban.length()==0){
            binding.enterIban.setError("Enter Email");
            binding.enterIban.requestFocus();
        }
         else if (country.length()==0){
            binding.enterCountry.setError("Enter country");
            binding.enterCountry.requestFocus();
        }
         else if (city.length()==0){
            binding.enterCity.setError("Enter city");
            binding.enterCity.requestFocus();
        }
         else if (address.length()==0){
            binding.enterAddress.setError("Enter address");
            binding.enterAddress.requestFocus();
        }
         else if (zipcode.length()==0){
            binding.enterZipCode.setError("Enter zipcode");
            binding.enterZipCode.requestFocus();
        }
         else{

            new Mvvm().someoneElseRootLiveData(requireActivity(), CommonUtil.getUserId(),"2",email,name,
                    iban,country,city,address,zipcode,"").observe(requireActivity(), new Observer<SomeoneElseRoot>() {
                @Override
                public void onChanged(SomeoneElseRoot someoneElseRoot) {

                    if (someoneElseRoot.getStatus().equals("1")){

                        App.getAppPreference().saveStringValue("email",someoneElseRoot.getDetails().getEmail());
                        App.getAppPreference().saveStringValue("iban",someoneElseRoot.getDetails().getBankAccopuntNumber());
                        App.getAppPreference().saveStringValue("code",someoneElseRoot.getDetails().getBankCode());
                        App.getAppPreference().saveStringValue("name",someoneElseRoot.getDetails().getHolderAccountName());

                        Bundle bundle = new Bundle();
                        bundle.putString("email",binding.enterEmail.getText().toString());
                        bundle.putString("iban",binding.enterIban.getText().toString());
                        bundle.putString("code",binding.enterZipCode.getText().toString());
                        bundle.putString("name",binding.enterHolderName.getText().toString());
                        Navigation.findNavController(requireActivity(), R.id.nav_home).navigate(R.id.action_someoneElseFragment_to_reviewDetailsFragment);
                        //   Toast.makeText(requireActivity(), ""+someoneElseRoot.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(requireActivity(), ""+someoneElseRoot.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }
    @Override
    public void onResume() {
        super.onResume();
        requireActivity().findViewById(R.id.bottom_nav).setVisibility(View.GONE);
    }
}