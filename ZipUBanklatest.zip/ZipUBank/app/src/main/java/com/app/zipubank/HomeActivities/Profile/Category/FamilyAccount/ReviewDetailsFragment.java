package com.app.zipubank.HomeActivities.Profile.Category.FamilyAccount;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;


import com.app.zipubank.R;

import com.app.zipubank.databinding.FragmentReviewDetailsBinding;
import com.app.zipubank.models.Currency.CurrencyRoot;
import com.app.zipubank.utils.App;
import com.google.android.material.navigation.NavigationView;

import org.jetbrains.annotations.NotNull;

public class ReviewDetailsFragment extends Fragment {
    FragmentReviewDetailsBinding fragmentReviewDetailsBinding;
    public static CurrencyRoot detailCurrency;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        fragmentReviewDetailsBinding = FragmentReviewDetailsBinding.inflate(getLayoutInflater());
        return fragmentReviewDetailsBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        setData();
        fragmentReviewDetailsBinding.goToSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(requireActivity(),R.id.nav_home).navigate(R.id.action_reviewDetailsFragment_to_internationalLocalFragment);
            }
        });
        fragmentReviewDetailsBinding.doneReviewDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(fragmentReviewDetailsBinding.getRoot()).navigate(R.id.action_reviewDetailsFragment_to_internationalLocalFragment);
            }
        });

        fragmentReviewDetailsBinding.change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(requireActivity(), R.id.nav_home).navigate(R.id.action_reviewDetailsFragment_to_someoneElseFragment);
            }
        });

        Bundle bundle = getArguments();

        if (bundle != null) {
            fragmentReviewDetailsBinding.setHolderName.setText("AO bank details for " + bundle.getString("namename"));
            fragmentReviewDetailsBinding.setEmail.setText(bundle.getString("email"));
            fragmentReviewDetailsBinding.setCode.setText(bundle.getString("code"));
            fragmentReviewDetailsBinding.setIban.setText(bundle.getString("iban"));

        } else {
            Toast.makeText(requireActivity(), "null", Toast.LENGTH_SHORT).show();
        }

    }

    private void setData() {
        fragmentReviewDetailsBinding.setHolderName.setText("AO bank detail for "+ App.getAppPreference().getStringValue("name"));
        fragmentReviewDetailsBinding.setEmail.setText(App.getAppPreference().getStringValue("email"));
        fragmentReviewDetailsBinding.setCode.setText(App.getAppPreference().getStringValue("code"));
        fragmentReviewDetailsBinding.setIban.setText(App.getAppPreference().getStringValue("iban"));



        if (detailCurrency != null) {
            fragmentReviewDetailsBinding.sentMoney.setText(detailCurrency.getDetails().getAmount() + " " + detailCurrency.getDetails().getBase());
            fragmentReviewDetailsBinding.commission.setText(detailCurrency.getDetails().getResult().getRate() + " " + detailCurrency.getDetails().getBase());
            fragmentReviewDetailsBinding.recieptGets.setText(String.valueOf(detailCurrency.getVar().getConstant()));
        } else {
            fragmentReviewDetailsBinding.sentMoney.setText("");
            fragmentReviewDetailsBinding.commission.setText("");
            fragmentReviewDetailsBinding.recieptGets.setText("");
        }
    }
}