package com.app.zipubank;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;

import com.app.zipubank.databinding.FragmentByCardPaymentBinding;
import com.app.zipubank.models.CardDetailsRoot;
import com.app.zipubank.retrofit.Mvvm;
import com.app.zipubank.utils.CommonUtil;

import org.jetbrains.annotations.NotNull;

import java.util.Calendar;


public class ByCardPaymentFragment extends Fragment {
    FragmentByCardPaymentBinding fragmentByCardPaymentBinding;
    int current_year;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        fragmentByCardPaymentBinding = FragmentByCardPaymentBinding.inflate(getLayoutInflater());
        return fragmentByCardPaymentBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        current_year = Calendar.getInstance().get(Calendar.YEAR);

        fragmentByCardPaymentBinding.saveCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (fragmentByCardPaymentBinding.enterCardNumb.getText().toString().length()<16|| fragmentByCardPaymentBinding.enterCardNumb.getText().toString().length()>16 ) {
                    fragmentByCardPaymentBinding.enterCardNumb.setError("Invalid Number");
                    fragmentByCardPaymentBinding.enterCardNumb.requestFocus();
                } else if (fragmentByCardPaymentBinding.enterHolderName.getText().toString().length() == 0) {
                    fragmentByCardPaymentBinding.enterHolderName.setError("Enter Name");
                    fragmentByCardPaymentBinding.enterHolderName.requestFocus();
                } else if (fragmentByCardPaymentBinding.enterExpMonth.getText().toString().length() > 2 || fragmentByCardPaymentBinding.enterExpMonth.getText().toString().length() < 2) {
                    Toast.makeText(requireContext(), "Invalid Date", Toast.LENGTH_SHORT).show();
                } else if (Integer.parseInt(fragmentByCardPaymentBinding.enterExpYear.getText().toString()) < current_year || Integer.parseInt(fragmentByCardPaymentBinding.enterExpYear.getText().toString()) == current_year) {
                    Toast.makeText(requireContext(), "Invalid Date", Toast.LENGTH_SHORT).show();
                } else if (fragmentByCardPaymentBinding.entrCvv.getText().toString().length() > 3 && fragmentByCardPaymentBinding.entrCvv.getText().toString().length() < 4) {
                    Toast.makeText(requireContext(), "Invalid Cvv", Toast.LENGTH_SHORT).show();
                } else {
                    new Mvvm().addCardRootLiveData(requireActivity(), CommonUtil.getUserId(),
                            fragmentByCardPaymentBinding.enterCardNumb.getText().toString(), fragmentByCardPaymentBinding.enterHolderName.getText().toString(),
                            fragmentByCardPaymentBinding.entrCvv.getText().toString(), fragmentByCardPaymentBinding.enterExpYear.getText().toString(),
                            fragmentByCardPaymentBinding.enterExpMonth.getText().toString(), "master").observe(requireActivity(), new Observer<CardDetailsRoot>() {
                        @Override
                        public void onChanged(CardDetailsRoot cardDetailsRoot) {
                            if (cardDetailsRoot.getStatus().equals("1")) {
                       //         Toast.makeText(requireActivity(), "" + cardDetailsRoot.getMesage(), Toast.LENGTH_SHORT).show();
                                Navigation.findNavController(requireActivity(), R.id.nav_home).navigate(R.id.action_byCardPaymentFragment_to_payByCardFragment);
                            } else {
                                Toast.makeText(requireActivity(), "" + cardDetailsRoot.getMesage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        requireActivity().findViewById(R.id.bottom_nav).setVisibility(View.GONE);
    }
}