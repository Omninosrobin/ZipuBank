package com.app.zipubank.retrofit;

import android.app.Activity;
import android.widget.Toast;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.app.zipubank.HomeActivities.Profile.Category.FamilyAccount.PostContactsResponse;
import com.app.zipubank.HomeActivities.Profile.Category.FamilyAccount.UnMatchedContacts;
import com.app.zipubank.models.AccountRoot;
import com.app.zipubank.models.AccountStatusRoot;
import com.app.zipubank.models.BankListRoot;
import com.app.zipubank.models.BankStatusRoot;
import com.app.zipubank.models.CardDetailsRoot;
import com.app.zipubank.models.CountryRoot;
import com.app.zipubank.models.Currency.CurrencyRoot;
import com.app.zipubank.models.GetContactsList;
import com.app.zipubank.models.GetMyBankDetail;
import com.app.zipubank.models.LogoutModel;
import com.app.zipubank.models.NewPassword;
import com.app.zipubank.models.OtpForgotpass;
import com.app.zipubank.models.OtpModel;
import com.app.zipubank.models.Receipt.SomeoneElse.SomeoneElseGetRoot;
import com.app.zipubank.models.Receipt.SomeoneElse.SomeoneElseRoot;
import com.app.zipubank.models.RegisterModel;
import com.app.zipubank.models.ShowCardDetailRoot;
import com.app.zipubank.models.UserBankDetailRoot;
import com.app.zipubank.utils.CommonUtil;
import com.google.gson.JsonObject;

import org.json.JSONObject;

import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Mvvm extends ViewModel {

    private ApiInterface apiInterface = BaseUrlRetrofit.getRetrofit().create(ApiInterface.class);


    private MutableLiveData<RegisterModel> matchOtp;

    public LiveData<RegisterModel> registerModelLiveData(final Activity activity, String phoneNumbe, String email, String password,
                                                         String device_type, String login_type, String device_id, String latitude,
                                                         String longitude, String reg_id, String accountType, String country, String state) {
        matchOtp = new MutableLiveData<>();
        if (CommonUtil.isNetworkConnected(activity)) {
            CommonUtil.showProgress(activity, "Loading.....");

            apiInterface.userRegister(phoneNumbe, email, password, device_type, login_type, device_id, latitude, longitude, reg_id, accountType, country, state).enqueue(new Callback<RegisterModel>() {
                @Override
                public void onResponse(Call<RegisterModel> call, Response<RegisterModel> response) {
                    CommonUtil.dismissProgress();
                    if (response.body() != null) {
                        matchOtp.postValue(response.body());
                    } else {
                        Toast.makeText(activity, "Technical Issues", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<RegisterModel> call, Throwable t) {
                    CommonUtil.dismissProgress();
                    Toast.makeText(activity, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        } else {

            Toast.makeText(activity, "No Internet Connection", Toast.LENGTH_SHORT).show();
        }
        return matchOtp;
    }

    private MutableLiveData<RegisterModel> userLogIn;

    public LiveData<RegisterModel> loginData(final Activity activity, String userEmail, String password) {
        userLogIn = new MutableLiveData<>();
        if (CommonUtil.isNetworkConnected(activity)) {
            CommonUtil.showProgress(activity, "Loading.....");

            apiInterface.userLogin(userEmail, password).enqueue(new Callback<RegisterModel>() {
                @Override
                public void onResponse(Call<RegisterModel> call, Response<RegisterModel> response) {
                    CommonUtil.dismissProgress();
                    if (response.body() != null) {
                        userLogIn.postValue(response.body());
                    } else {
                        Toast.makeText(activity, "Technical Issues", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<RegisterModel> call, Throwable t) {
                    CommonUtil.dismissProgress();
                    Toast.makeText(activity, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        } else {

            Toast.makeText(activity, "No Internet Connection", Toast.LENGTH_SHORT).show();
        }
        return userLogIn;
    }


    private MutableLiveData<LogoutModel> logout;

    public LiveData<LogoutModel> logoutUser(final Activity activity, String userId) {

        logout = new MutableLiveData<>();

        if (CommonUtil.isNetworkConnected(activity)) {
            CommonUtil.showProgress(activity, "");

            apiInterface.logoutUser(userId).enqueue(new Callback<LogoutModel>() {
                @Override
                public void onResponse(Call<LogoutModel> call, Response<LogoutModel> response) {
                    CommonUtil.dismissProgress();
                    if (response.body() != null) {
                        logout.postValue(response.body());
                    }
                }

                @Override
                public void onFailure(Call<LogoutModel> call, Throwable t) {
                    CommonUtil.dismissProgress();

                }
            });

        } else {
            Toast.makeText(activity, "No Internet Connection", Toast.LENGTH_SHORT).show();

        }
        return logout;
    }


    private MutableLiveData<OtpModel> otpModelMutableLiveData;

    public LiveData<OtpModel> otpModelLiveData(final Activity activity, String userId) {

        otpModelMutableLiveData = new MutableLiveData<>();

        if (CommonUtil.isNetworkConnected(activity)) {

            CommonUtil.showProgress(activity, "");

            apiInterface.validPhone(userId).enqueue(new Callback<OtpModel>() {
                @Override
                public void onResponse(Call<OtpModel> call, Response<OtpModel> response) {
                    CommonUtil.dismissProgress();
                    if (response.body() != null) {
                        otpModelMutableLiveData.postValue(response.body());
                    }
                }

                @Override
                public void onFailure(Call<OtpModel> call, Throwable t) {
                    CommonUtil.dismissProgress();

                }
            });

        } else {
            Toast.makeText(activity, "No Internet Connection", Toast.LENGTH_SHORT).show();

        }
        return otpModelMutableLiveData;
    }

    private MutableLiveData<OtpModel> addMyBankAccountMutable;

    public LiveData<OtpModel> addMyBankAccountLive(final Activity activity, String userid, String username, String iban, String bank_name, String bank_image) {

        addMyBankAccountMutable = new MutableLiveData<>();

        if (CommonUtil.isNetworkConnected(activity)) {

            CommonUtil.showProgress(activity, "");

            apiInterface.addMyBankAccount(userid, username, iban, bank_name, bank_image).enqueue(new Callback<OtpModel>() {
                @Override
                public void onResponse(Call<OtpModel> call, Response<OtpModel> response) {
                    CommonUtil.dismissProgress();
                    if (response.body() != null) {
                        addMyBankAccountMutable.postValue(response.body());
                    }
                }

                @Override
                public void onFailure(Call<OtpModel> call, Throwable t) {
                    CommonUtil.dismissProgress();
                }
            });

        } else {
            Toast.makeText(activity, "No Internet Connection", Toast.LENGTH_SHORT).show();

        }
        return addMyBankAccountMutable;
    }

    private MutableLiveData<GetMyBankDetail> getAddMyBankAccountMutable;

    public LiveData<GetMyBankDetail> getAddMyBankAccountLive(final Activity activity, String userId) {

        getAddMyBankAccountMutable = new MutableLiveData<>();

        if (CommonUtil.isNetworkConnected(activity)) {

            CommonUtil.showProgress(activity, "");

            apiInterface.getAddMyBankAccount(userId).enqueue(new Callback<GetMyBankDetail>() {
                @Override
                public void onResponse(Call<GetMyBankDetail> call, Response<GetMyBankDetail> response) {
                    CommonUtil.dismissProgress();
                    if (response.body() != null) {
                        getAddMyBankAccountMutable.postValue(response.body());
                    }
                }

                @Override
                public void onFailure(Call<GetMyBankDetail> call, Throwable t) {
                    CommonUtil.dismissProgress();
                }
            });

        } else {
            Toast.makeText(activity, "No Internet Connection", Toast.LENGTH_SHORT).show();

        }
        return getAddMyBankAccountMutable;
    }


    private MutableLiveData<RegisterModel> update;

    public LiveData<RegisterModel> UpdateUserProfile(Activity activity, RequestBody name, RequestBody gender, RequestBody dob, RequestBody latitude, RequestBody longitude, RequestBody id, MultipartBody.Part profileImage) {
        update = new MutableLiveData<>();
        if (CommonUtil.isNetworkConnected(activity)) {
            CommonUtil.showProgress(activity, "Loading....");

            apiInterface.updateUser(name, gender, dob, latitude, longitude, id, profileImage).enqueue(new Callback<RegisterModel>() {
                @Override
                public void onResponse(Call<RegisterModel> call, Response<RegisterModel> response) {
                    CommonUtil.dismissProgress();
                    if (response.body() != null) {
                        update.postValue(response.body());
                    } else {
                        Toast.makeText(activity, "Technical  Issue", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<RegisterModel> call, Throwable t) {
                    CommonUtil.dismissProgress();
                    Toast.makeText(activity, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            Toast.makeText(activity, "Check  Internet Connection", Toast.LENGTH_SHORT).show();
        }
        return update;
    }

    private MutableLiveData<AccountRoot> createAccount;

    public LiveData<AccountRoot> CreateAccountMutableLiveData(Activity activity, RequestBody country_name,
                                                              RequestBody first_name, RequestBody last_name,
                                                              RequestBody dob, RequestBody address, RequestBody document_name,
                                                              RequestBody city, RequestBody accountStatus, MultipartBody.Part face_image, MultipartBody.Part document_image,
                                                              RequestBody userId) {
        createAccount = new MutableLiveData<>();
        if (CommonUtil.isNetworkConnected(activity)) {
            CommonUtil.showProgress(activity, "Loading....");
            apiInterface.createUserAccount(country_name, first_name, last_name, dob, address, document_name, city, accountStatus, face_image, document_image, userId).enqueue(new Callback<AccountRoot>() {
                @Override
                public void onResponse(Call<AccountRoot> call, Response<AccountRoot> response) {
                    CommonUtil.dismissProgress();
                    if (response.body() != null) {
                        createAccount.postValue(response.body());
                    } else {
                        Toast.makeText(activity, "Technical  Issue", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<AccountRoot> call, Throwable t) {
                    CommonUtil.dismissProgress();
                    Toast.makeText(activity, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            Toast.makeText(activity, "Check  Internet Connection", Toast.LENGTH_SHORT).show();
        }
        return createAccount;
    }

    private MutableLiveData<CountryRoot> countryRootMutableLiveData;

    public LiveData<CountryRoot> countryRootLiveData(Activity activity) {
        countryRootMutableLiveData = new MutableLiveData<>();
        //nUtil.isNetworkConnected(activity)) {
        apiInterface.getCountryList().enqueue(new Callback<CountryRoot>() {
            @Override
            public void onResponse(Call<CountryRoot> call, Response<CountryRoot> response) {
                if (response.body() != null) {
                    countryRootMutableLiveData.postValue(response.body());
                } else {
                    Toast.makeText(activity, "Technical  Issue", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<CountryRoot> call, Throwable t) {
                Toast.makeText(activity, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
//        } else {
//            Toast.makeText(activity, "Check  Internet Connection", Toast.LENGTH_SHORT).show();
//        }
        return countryRootMutableLiveData;
    }

    private MutableLiveData<AccountStatusRoot> accountStatusRootMutableLiveData;

    public LiveData<AccountStatusRoot> accountStatusRootLiveData(Activity activity, String id) {
        accountStatusRootMutableLiveData = new MutableLiveData<>();
//        if (CommonUtil.isNetworkConnected(activity)) {
//            CommonUtil.showProgress(activity, "Loading....");
        apiInterface.getAccountStatus(id).enqueue(new Callback<AccountStatusRoot>() {
            @Override
            public void onResponse(Call<AccountStatusRoot> call, Response<AccountStatusRoot> response) {
                //       CommonUtil.dismissProgress();
                if (response.body() != null) {
                    accountStatusRootMutableLiveData.postValue(response.body());
                } else {
                    Toast.makeText(activity, "Technical  Issue", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<AccountStatusRoot> call, Throwable t) {
                CommonUtil.dismissProgress();
                Toast.makeText(activity, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
//        } else {
//            Toast.makeText(activity, "Check  Internet Connection", Toast.LENGTH_SHORT).show();
//        }
        return accountStatusRootMutableLiveData;
    }

    private MutableLiveData<BankStatusRoot> bankStatusRootMutableLiveData;

    public LiveData<BankStatusRoot> bankStatusRootLiveData(Activity activity, String userId) {
        bankStatusRootMutableLiveData = new MutableLiveData<>();
//        if (CommonUtil.isNetworkConnected(activity)) {
        apiInterface.getBankAcccountStatus(userId).enqueue(new Callback<BankStatusRoot>() {
            @Override
            public void onResponse(Call<BankStatusRoot> call, Response<BankStatusRoot> response) {
                if (response.body() != null) {
                    bankStatusRootMutableLiveData.postValue(response.body());
                } else {
                    Toast.makeText(activity, "Technical  Issue", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<BankStatusRoot> call, Throwable t) {
                Toast.makeText(activity, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
//        } else {
//            Toast.makeText(activity, "Check  Internet Connection", Toast.LENGTH_SHORT).show();
//        }
        return bankStatusRootMutableLiveData;
    }

    private MutableLiveData<Map> addAmountMutableData;

    public LiveData<Map> addAmountLiveData(Activity activity, String userId, String walletId, String wallet_amount, String type) {
        addAmountMutableData = new MutableLiveData<>();
//        if (CommonUtil.isNetworkConnected(activity)) {
//            CommonUtil.showProgress(activity, "Loading....");
        apiInterface.addMoneyToWallet(userId, walletId, wallet_amount, type).enqueue(new Callback<Map>() {
            @Override
            public void onResponse(Call<Map> call, Response<Map> response) {
                //            CommonUtil.dismissProgress();
                if (response.body() != null) {
                    addAmountMutableData.postValue(response.body());
                } else {
                    Toast.makeText(activity, "Technical  Issue", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Map> call, Throwable t) {
                CommonUtil.dismissProgress();
                Toast.makeText(activity, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
//        } else {
//            Toast.makeText(activity, "Check  Internet Connection", Toast.LENGTH_SHORT).show();
//        }
        return addAmountMutableData;
    }

    private MutableLiveData<CardDetailsRoot> addCardRootMutableLiveData;

    public LiveData<CardDetailsRoot> addCardRootLiveData(Activity activity, String userId, String cardNumber, String name, String cvv, String expiryYear, String expiryMonth, String cardType) {
        addCardRootMutableLiveData = new MutableLiveData<>();
//        if (CommonUtil.isNetworkConnected(activity)) {
//            CommonUtil.showProgress(activity, "Loading....");
        apiInterface.addCard(userId, cardNumber, name, cvv, expiryYear, expiryMonth, cardType).enqueue(new Callback<CardDetailsRoot>() {
            @Override
            public void onResponse(Call<CardDetailsRoot> call, Response<CardDetailsRoot> response) {
                //    CommonUtil.dismissProgress();
                if (response.body() != null) {
                    addCardRootMutableLiveData.postValue(response.body());
                } else {
                    Toast.makeText(activity, "Technical  Issue", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<CardDetailsRoot> call, Throwable t) {
                CommonUtil.dismissProgress();
                Toast.makeText(activity, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
//        } else {
//            Toast.makeText(activity, "Check  Internet Connection", Toast.LENGTH_SHORT).show();
//        }
        return addCardRootMutableLiveData;
    }

    private MutableLiveData<ShowCardDetailRoot> getCardRootMutableLiveData;

    public LiveData<ShowCardDetailRoot> getCardDetailsRootLiveData(Activity activity, String userId) {
        getCardRootMutableLiveData = new MutableLiveData<>();
//        if (CommonUtil.isNetworkConnected(activity)) {
//            CommonUtil.showProgress(activity, "Loading....");
        apiInterface.getCard(userId).enqueue(new Callback<ShowCardDetailRoot>() {
            @Override
            public void onResponse(Call<ShowCardDetailRoot> call, Response<ShowCardDetailRoot> response) {
                //     CommonUtil.dismissProgress();
                if (response.body() != null) {
                    getCardRootMutableLiveData.postValue(response.body());
                } else {
                    Toast.makeText(activity, "Technical  Issue", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ShowCardDetailRoot> call, Throwable t) {
                CommonUtil.dismissProgress();
                Toast.makeText(activity, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
//        } else {
//            Toast.makeText(activity, "Check  Internet Connection", Toast.LENGTH_SHORT).show();
//        }
        return getCardRootMutableLiveData;
    }

    private MutableLiveData<Map> removeCardRootMutableLiveData;

    public LiveData<Map> removeCardRootLiveData(Activity activity, String userId, String id) {
        removeCardRootMutableLiveData = new MutableLiveData<>();
//        if (CommonUtil.isNetworkConnected(activity)) {
//            CommonUtil.showProgress(activity, "Loading....");
        apiInterface.removeCard(userId, id).enqueue(new Callback<Map>() {
            @Override
            public void onResponse(Call<Map> call, Response<Map> response) {
                //   CommonUtil.dismissProgress();
                if (response.body() != null) {
                    removeCardRootMutableLiveData.postValue(response.body());
                } else {
                    Toast.makeText(activity, "Technical  Issue", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Map> call, Throwable t) {
                //   CommonUtil.dismissProgress();
                Toast.makeText(activity, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
//        } else {
//            Toast.makeText(activity, "Check  Internet Connection", Toast.LENGTH_SHORT).show();
//        }
        return removeCardRootMutableLiveData;
    }

    private MutableLiveData<BankListRoot> bankListRootMutableLiveData;

    public LiveData<BankListRoot> bankListRootLiveData(Activity activity) {
        bankListRootMutableLiveData = new MutableLiveData<>();
//        if (CommonUtil.isNetworkConnected(activity)) {
        apiInterface.getBankList().enqueue(new Callback<BankListRoot>() {
            @Override
            public void onResponse(Call<BankListRoot> call, Response<BankListRoot> response) {
                if (response.body() != null) {
                    bankListRootMutableLiveData.postValue(response.body());
                } else {
                    Toast.makeText(activity, "Technical  Issue", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<BankListRoot> call, Throwable t) {
                Toast.makeText(activity, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
//        } else {
//            Toast.makeText(activity, "Check  Internet Connection", Toast.LENGTH_SHORT).show();
//        }
        return bankListRootMutableLiveData;
    }

    private MutableLiveData<CurrencyRoot> currencyRootMutableLiveData;

    public LiveData<CurrencyRoot> currencyRootLiveData(Activity activity, String from, String to, String amount) {
        currencyRootMutableLiveData = new MutableLiveData<>();
//        if (CommonUtil.isNetworkConnected(activity)) {
//            CommonUtil.showProgress(activity, "Loading....");
        apiInterface.currencyConverter(from, to, amount).enqueue(new Callback<CurrencyRoot>() {
            @Override
            public void onResponse(Call<CurrencyRoot> call, Response<CurrencyRoot> response) {
                CommonUtil.dismissProgress();
                if (response.body() != null) {
                    currencyRootMutableLiveData.postValue(response.body());
                } else {
                    Toast.makeText(activity, "Technical  Issue", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<CurrencyRoot> call, Throwable t) {
                CommonUtil.dismissProgress();
                Toast.makeText(activity, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
//        } else {
//            Toast.makeText(activity, "Check  Internet Connection", Toast.LENGTH_SHORT).show();
//        }
        return currencyRootMutableLiveData;
    }

    private MutableLiveData<SomeoneElseRoot> someoneElseRootMutableLiveData;

    public LiveData<SomeoneElseRoot> someoneElseRootLiveData(Activity activity, String userId, String recipientType,
                                                             String email, String holderAccountName, String bankAccopuntNumber,
                                                             String country, String city, String address, String zipcode, String bankCode) {
        someoneElseRootMutableLiveData = new MutableLiveData<>();
//        if (CommonUtil.isNetworkConnected(activity)) {
//            CommonUtil.showProgress(activity, "Loading....");
        apiInterface.someoneElseReceipt(userId, recipientType, email, holderAccountName, bankAccopuntNumber, country, city, address, zipcode, bankCode).enqueue(new Callback<SomeoneElseRoot>() {
            @Override
            public void onResponse(Call<SomeoneElseRoot> call, Response<SomeoneElseRoot> response) {
                CommonUtil.dismissProgress();
                if (response.body() != null) {
                    someoneElseRootMutableLiveData.postValue(response.body());
                } else {
                    Toast.makeText(activity, "Technical  Issue", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<SomeoneElseRoot> call, Throwable t) {
                CommonUtil.dismissProgress();
                Toast.makeText(activity, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
//        } else {
//            Toast.makeText(activity, "Check  Internet Connection", Toast.LENGTH_SHORT).show();
//        }
        return someoneElseRootMutableLiveData;
    }

    private MutableLiveData<SomeoneElseGetRoot> getSomeoneRootMutableLiveData;

    public LiveData<SomeoneElseGetRoot> getSomeoneRootLiveData(Activity activity, String userId) {
        getSomeoneRootMutableLiveData = new MutableLiveData<>();
//        if (CommonUtil.isNetworkConnected(activity)) {
//            CommonUtil.showProgress(activity, "Loading....");
        apiInterface.getSomeoneElseReceipt(userId).enqueue(new Callback<SomeoneElseGetRoot>() {
            @Override
            public void onResponse(Call<SomeoneElseGetRoot> call, Response<SomeoneElseGetRoot> response) {
                CommonUtil.dismissProgress();
                if (response.body() != null) {
                    getSomeoneRootMutableLiveData.postValue(response.body());
                } else {
                    Toast.makeText(activity, "Technical  Issue", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<SomeoneElseGetRoot> call, Throwable t) {
                CommonUtil.dismissProgress();
                Toast.makeText(activity, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
//        } else {
//            Toast.makeText(activity, "Check  Internet Connection", Toast.LENGTH_SHORT).show();
//        }
        return getSomeoneRootMutableLiveData;
    }

    // Add contacts list detail
    private MutableLiveData<Map> addContacts;

    public LiveData<Map> addContactsModelLiveData(Activity activity, JsonObject userContact) {
        addContacts = new MutableLiveData<>();
//        if (CommonUtil.isNetworkConnected(activity)) {
//            CommonUtil.showProgress(activity, "Loading....");
        apiInterface.userContact(userContact).enqueue(new Callback<Map>() {
            @Override
            public void onResponse(Call<Map> call, Response<Map> response) {
                if (response.body() != null) {
                    addContacts.postValue(response.body());
                } else {
                    Toast.makeText(activity, "Issue in  Model" + response.body(), Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onFailure(Call<Map> call, Throwable t) {
                CommonUtil.dismissProgress();
                Toast.makeText(activity, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
//        } else {
//            Toast.makeText(activity, "Check  Internet Connection", Toast.LENGTH_SHORT).show();
//        }
        return addContacts;
    }


    // Forgot Password
    private MutableLiveData<OtpForgotpass> otpForgotpassMutableLiveData;

    public LiveData<OtpForgotpass> otpForgotpassLiveData(Activity activity, String email) {
        otpForgotpassMutableLiveData = new MutableLiveData<>();
        apiInterface.forgetPassword(email).enqueue(new Callback<OtpForgotpass>() {
            @Override
            public void onResponse(Call<OtpForgotpass> call, Response<OtpForgotpass> response) {
                if (response.body() != null) {
                    otpForgotpassMutableLiveData.postValue(response.body());
                } else {
                    Toast.makeText(activity, "Techical Issue in ViewModel", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<OtpForgotpass> call, Throwable t) {

                Toast.makeText(activity, "Failure" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        return otpForgotpassMutableLiveData;
    }

    // New PAssword
    private MutableLiveData<NewPassword> newPasswordMutableLiveData;

    public LiveData<NewPassword> newPasswordLiveData(Activity activity, String email, String password) {
        newPasswordMutableLiveData = new MutableLiveData<>();
        apiInterface.changePassword(email, password).enqueue(new Callback<NewPassword>() {
            @Override
            public void onResponse(Call<NewPassword> call, Response<NewPassword> response) {
                if (response.body() != null) {
                    newPasswordMutableLiveData.postValue(response.body());
                } else {
                    Toast.makeText(activity, "Techical Issue in ViewModel", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<NewPassword> call, Throwable t) {

                Toast.makeText(activity, "Failure" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        return newPasswordMutableLiveData;
    }

    private MutableLiveData<GetContactsList> getContactsListMutableLiveData;

    public LiveData<GetContactsList> getContactsListLiveData(Activity activity, String userId) {
        getContactsListMutableLiveData = new MutableLiveData<>();
        apiInterface.getUserContacts(userId).enqueue(new Callback<GetContactsList>() {
            @Override
            public void onResponse(Call<GetContactsList> call, Response<GetContactsList> response) {
                if (response.body() != null) {
                    getContactsListMutableLiveData.postValue(response.body());
                } else {
                    Toast.makeText(activity, "Issue in Model", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<GetContactsList> call, Throwable t) {
                Toast.makeText(activity, "Failure" + t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
        return getContactsListMutableLiveData;
    }


    private MutableLiveData<UnMatchedContacts> unMatchedContactsMutableLiveData;

    public LiveData<UnMatchedContacts> unMatchedContactsLiveData(Activity activity, String userId) {
        unMatchedContactsMutableLiveData = new MutableLiveData<>();
        apiInterface.getUnMatchedUserContacts(userId).enqueue(new Callback<UnMatchedContacts>() {
            @Override
            public void onResponse(Call<UnMatchedContacts> call, Response<UnMatchedContacts> response) {
                if (response.body() != null) {
                    unMatchedContactsMutableLiveData.postValue(response.body());
                } else {
                    Toast.makeText(activity, "Technical issue in view model", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<UnMatchedContacts> call, Throwable t) {
                Toast.makeText(activity, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        return unMatchedContactsMutableLiveData;
    }

    private MutableLiveData<UserBankDetailRoot> bankDetailRootMutableLiveData;

    public LiveData<UserBankDetailRoot> bankDetailRootLiveData(Activity activity, String userId) {
        bankDetailRootMutableLiveData = new MutableLiveData<>();
        apiInterface.getuserBankAccount(userId).enqueue(new Callback<UserBankDetailRoot>() {
            @Override
            public void onResponse(Call<UserBankDetailRoot> call, Response<UserBankDetailRoot> response) {
                if (response.body() != null) {
                    bankDetailRootMutableLiveData.postValue(response.body());
                } else {
                    Toast.makeText(activity, "Technical issue in View Model", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<UserBankDetailRoot> call, Throwable t) {
                Toast.makeText(activity, "" + t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
        return bankDetailRootMutableLiveData;
    }
}
