package com.app.zipubank.models;

import java.io.Serializable;

public class CountryDetails implements Serializable {

    public String countryCode;
    public String image;

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
