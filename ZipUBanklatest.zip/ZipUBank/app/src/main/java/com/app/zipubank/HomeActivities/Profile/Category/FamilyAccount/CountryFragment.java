package com.app.zipubank.HomeActivities.Profile.Category.FamilyAccount;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;

import com.app.zipubank.R;
import com.app.zipubank.databinding.FragmentCountryBinding;
import com.app.zipubank.models.CountryClass;
import com.app.zipubank.models.CountryRoot;
import com.app.zipubank.retrofit.Mvvm;
import com.app.zipubank.utils.App;

import java.util.ArrayList;

public class CountryFragment extends Fragment {
    FragmentCountryBinding fragmentCountryBinding;
    String country, state, countryNameString;
    public static String country_code, country_img;
    Bundle bundle;
    ArrayList<String> countryListRoots = new ArrayList<>();
    ArrayList<CountryClass> list = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        fragmentCountryBinding = FragmentCountryBinding.inflate(getLayoutInflater());

        onClicks();

        new Mvvm().countryRootLiveData(requireActivity()).observe(requireActivity(), new Observer<CountryRoot>() {
            @Override
            public void onChanged(CountryRoot countryRoot) {
                if (countryRoot.getSuccess().equalsIgnoreCase("1")) {
                    Toast.makeText(requireContext(), "" + countryRoot.getMessage(), Toast.LENGTH_SHORT).show();
                    list = countryRoot.getDetails();
                    setSpinnerAdapter(list);

                } else {
                    Toast.makeText(requireContext(), "" + countryRoot.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });



        return fragmentCountryBinding.getRoot();
    }

    private void onClicks() {


        fragmentCountryBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requireActivity().onBackPressed();
            }
        });
        fragmentCountryBinding.continueCountry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                state = fragmentCountryBinding.stateName.getText().toString().trim();

                App.getSingleton().setCountryName(countryNameString);
                App.getSingleton().setStateName(state);
                if (state.isEmpty()) {
                    fragmentCountryBinding.stateName.setError("Enter your state name");
                } else if (countryNameString == null) {
                    Toast.makeText(requireContext(), "Select Country", Toast.LENGTH_SHORT).show();
                } else {
                    Navigation.findNavController(fragmentCountryBinding.getRoot()).navigate(R.id.verifyNumberFragment2);

                }


            }
        });
    }

    private void setSpinnerAdapter(ArrayList<CountryClass> list) {
        countryListRoots.clear();
        countryListRoots.add("Select Country");
        for (int i = 0; i < list.size(); i++) {
            countryListRoots.add(list.get(i).getCountryName());
        }

        ArrayAdapter<String> adp2 = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, countryListRoots);
        adp2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fragmentCountryBinding.countryName.setAdapter(adp2);
        fragmentCountryBinding.countryName.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0) {
                    countryNameString = null;
                } else {
                    countryNameString = countryListRoots.get(i);
                    country_code = list.get(i - 1).getCountryCode();
                    country_img = list.get(i - 1).getImage();
//                    Toast.makeText(requireContext(), "" + countryNameString, Toast.LENGTH_SHORT).show();
//                    Toast.makeText(requireContext(), "" + country_img, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
}