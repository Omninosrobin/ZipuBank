package com.app.zipubank.HomeActivities.Profile.Category.FamilyAccount;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.app.zipubank.Adapter.AdapterAddbank;
import com.app.zipubank.R;
import com.app.zipubank.databinding.FragmentAddUserBankBinding;
import com.app.zipubank.models.UserBankDetailRoot;
import com.app.zipubank.retrofit.Mvvm;
import com.app.zipubank.utils.CommonUtil;

import java.util.ArrayList;
import java.util.List;


public class AddUserBank extends Fragment implements AdapterAddbank.Callback{
FragmentAddUserBankBinding bankBinding;
ArrayList<UserBankDetailRoot.Detail> list=new ArrayList<>();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        bankBinding=FragmentAddUserBankBinding.inflate(getLayoutInflater());
        return  bankBinding.getRoot();

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setApi();
    }

    private void setApi() {
        new Mvvm().bankDetailRootLiveData(requireActivity(), CommonUtil.getUserId()).observe(requireActivity(), new Observer<UserBankDetailRoot>() {
            @Override
            public void onChanged(UserBankDetailRoot userBankDetailRoot) {
                if (userBankDetailRoot.getSuccess().equalsIgnoreCase("1")){
                    list=userBankDetailRoot.getDetails();
                    AdapterAddbank adapterAddbank=new AdapterAddbank(list,requireContext(),AddUserBank.this);
                    bankBinding.recyclerBank.setAdapter(adapterAddbank);
                }else {

                    Toast.makeText(requireContext(), "Root is Null", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public void callback(UserBankDetailRoot.Detail list) {
        if(list != null){

            Navigation.findNavController(requireActivity(),R.id.nav_home).navigate(R.id.action_addUserBank_to_sendMoney);

        }else{

        }
    }
}