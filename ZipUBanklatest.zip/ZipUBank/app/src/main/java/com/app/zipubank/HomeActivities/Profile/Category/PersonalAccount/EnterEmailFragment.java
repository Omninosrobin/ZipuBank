package com.app.zipubank.HomeActivities.Profile.Category.PersonalAccount;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.os.PatternMatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.app.zipubank.R;
import com.app.zipubank.databinding.FragmentEnterEmailBinding;
import com.app.zipubank.utils.App;

import org.jetbrains.annotations.NotNull;


public class EnterEmailFragment extends Fragment {
    FragmentEnterEmailBinding fragmentEnterEmailBinding;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       fragmentEnterEmailBinding = FragmentEnterEmailBinding.inflate(getLayoutInflater());



       onClicks();

       return fragmentEnterEmailBinding.getRoot();
    }

        private Boolean validateEmail() {
            String val = fragmentEnterEmailBinding.emailAddress.getText().toString();
            String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

            if (val.isEmpty()) {
                fragmentEnterEmailBinding.emailAddress.setError("Field cannot be empty");
                return false;
            } else if (!val.matches(emailPattern)) {
                fragmentEnterEmailBinding.emailAddress.setError("Invalid email address");
                return false;
            } else {
                fragmentEnterEmailBinding.emailAddress.setError(null);
                return true;
            }
        }


    private void onClicks() {

        fragmentEnterEmailBinding.imgBack.setOnClickListener(view -> requireActivity().onBackPressed());

            fragmentEnterEmailBinding.continueId.setOnClickListener(view -> {

                if (!validateEmail())
                {
                    return;

                } else {

                    App.getSingleton().setDocEmail(fragmentEnterEmailBinding.emailAddress.getText().toString());

                    Navigation.findNavController(fragmentEnterEmailBinding.getRoot()).navigate(R.id.kindOfAccount2);

                }

        });
    }
}