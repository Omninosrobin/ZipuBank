package com.app.zipubank.utils;


import java.util.List;

public class Singleton {

    public String otp;
    public String forgot_otp;
    private String forgot_phone;
    public String user;
    public String otp_HV;
    public String otp_update_HV;
    public String email;
    public String phone;
    public String pass;
    public String UserType;
    public String address;
    public String about;
    public String id;
    public String profileImage;
    public String name;
    public String surname;
    public String service_subcat_id;
    public String registerAs_hv;
    public String hospitalName_hv;
    public String email_hv;
    public String password_hv;
    public String PharmacyService_hv;
    public String phone_hv;
    public String icu_Bed_hv;
    public String generalWard_Bed_hv;
    public String address_hv;
    public String about_Hv;
    public String licenceNumber_hv;
    public String reg_id_hv;
    public String device_type_hv;
    public String login_type_hv;
    public String latitude_hv;
    public String AccountType;


//  For Register Screen

    private String string_Password;
    private String string_HospitalName;
    private String string_Email;
    private String string_ContactNum;
    private String string_License;
    private String string_HospitalType;
    private String hosLatitude;
    private String hosLongitude;
    private String department;
    private String officialNum;
    private String ambulanceNum;
    private String ambulanceType;
    private String ambulancePhoto;


    //    For DOCTOR LIST
    private String doctorID_DL;
    private String doctor_name_DL;
    private String doctor_photo_DL;
    private String speciality_DL;
    private String department_DL;
    private String medical_council_registration_DL;
    private String official_number_DL;
    private String qualification_DL;
    private String doctorUserID;
    private String doctorDob;
    private String doctorAddress;
    private String countryName;
    private String stateName;

    //    FOR SERVICES LIST
    private String serviceName;
    private String servicePrice;
    private String serviceImage;
    private String IDServices;


//    For MANAGE DOCUMENT

    private String mId_DOC;
    private String mDocumentName;
    private String mDocumentImage;
    private String driverEmail;
    private String driverID;

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public String getAccountType() {
        return AccountType;
    }

    public void setAccountType(String accountType) {
        AccountType = accountType;
    }

    public String getDoctorDob() {
        return doctorDob;
    }

    public String getHosLatitude() {
        return hosLatitude;
    }

    public void setHosLatitude(String hosLatitude) {
        this.hosLatitude = hosLatitude;
    }

    public String getHosLongitude() {
        return hosLongitude;
    }

    public void setHosLongitude(String hosLongitude) {
        this.hosLongitude = hosLongitude;
    }

    public void setDoctorDob(String doctorDob) {
        this.doctorDob = doctorDob;
    }

    public String getDoctorAddress() {
        return doctorAddress;
    }

    public void setDoctorAddress(String doctorAddress) {
        this.doctorAddress = doctorAddress;
    }

    public String getDriverEmail() {
        return driverEmail;
    }

    public void setDriverEmail(String driverEmail) {
        this.driverEmail = driverEmail;
    }

    public String getDriverID() {
        return driverID;
    }

    public void setDriverID(String driverID) {
        this.driverID = driverID;
    }
//  For Hospital License

    private String LicenseName;
    private String LicensePhoto;

    public String getLicenseName() {
        return LicenseName;
    }

    public void setLicenseName(String licenseName) {
        LicenseName = licenseName;
    }

    public String getLicensePhoto() {
        return LicensePhoto;
    }

    public void setLicensePhoto(String licensePhoto) {
        LicensePhoto = licensePhoto;
    }

    public String getmId_DOC() {
        return mId_DOC;
    }

    public void setmId_DOC(String mId_DOC) {
        this.mId_DOC = mId_DOC;
    }

    public String getmDocumentName() {
        return mDocumentName;
    }

    public void setmDocumentName(String mDocumentName) {
        this.mDocumentName = mDocumentName;
    }

    public String getmDocumentImage() {
        return mDocumentImage;
    }

    public void setmDocumentImage(String mDocumentImage) {
        this.mDocumentImage = mDocumentImage;
    }

    public String getIDServices() {
        return IDServices;
    }

    public void setIDServices(String IDServices) {
        this.IDServices = IDServices;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getServicePrice() {
        return servicePrice;
    }

    public void setServicePrice(String servicePrice) {
        this.servicePrice = servicePrice;
    }

    public String getServiceImage() {
        return serviceImage;
    }

    public void setServiceImage(String serviceImage) {
        this.serviceImage = serviceImage;
    }

    public String getDoctorID_DL() {
        return doctorID_DL;
    }

    public void setDoctorID_DL(String doctorID_DL) {
        this.doctorID_DL = doctorID_DL;
    }

    public String getDoctor_name_DL() {
        return doctor_name_DL;
    }

    public void setDoctor_name_DL(String doctor_name_DL) {
        this.doctor_name_DL = doctor_name_DL;
    }

    public String getDoctor_photo_DL() {
        return doctor_photo_DL;
    }

    public void setDoctor_photo_DL(String doctor_photo_DL) {
        this.doctor_photo_DL = doctor_photo_DL;
    }

    public String getSpeciality_DL() {
        return speciality_DL;
    }

    public void setSpeciality_DL(String speciality_DL) {
        this.speciality_DL = speciality_DL;
    }

    public String getDepartment_DL() {
        return department_DL;
    }

    public void setDepartment_DL(String department_DL) {
        this.department_DL = department_DL;
    }

    public String getMedical_council_registration_DL() {
        return medical_council_registration_DL;
    }

    public void setMedical_council_registration_DL(String medical_council_registration_DL) {
        this.medical_council_registration_DL = medical_council_registration_DL;
    }

    public String getOfficial_number_DL() {
        return official_number_DL;
    }

    public void setOfficial_number_DL(String official_number_DL) {
        this.official_number_DL = official_number_DL;
    }

    public String getQualification_DL() {
        return qualification_DL;
    }

    public void setQualification_DL(String qualification_DL) {
        this.qualification_DL = qualification_DL;
    }

    public String getId_Ambulance() {
        return id_Ambulance;
    }

    public void setId_Ambulance(String id_Ambulance) {
        this.id_Ambulance = id_Ambulance;
    }

    private String id_Ambulance;


    public String getString_Password() {
        return string_Password;
    }

    public void setString_Password(String string_Password) {
        this.string_Password = string_Password;
    }

    public String getString_HospitalName() {
        return string_HospitalName;
    }

    public void setString_HospitalName(String string_HospitalName) {
        this.string_HospitalName = string_HospitalName;
    }

    public String getString_Email() {
        return string_Email;
    }

    public void setString_Email(String string_Email) {
        this.string_Email = string_Email;
    }

    public String getString_ContactNum() {
        return string_ContactNum;
    }

    public void setString_ContactNum(String string_ContactNum) {
        this.string_ContactNum = string_ContactNum;
    }

    public String getString_License() {
        return string_License;
    }

    public void setString_License(String string_License) {
        this.string_License = string_License;
    }

    public String getString_HospitalType() {
        return string_HospitalType;
    }

    public void setString_HospitalType(String string_HospitalType) {
        this.string_HospitalType = string_HospitalType;
    }


//

    public String getRegisterAs_hv() {
        return registerAs_hv;
    }

    public void setRegisterAs_hv(String registerAs_hv) {
        this.registerAs_hv = registerAs_hv;
    }

    public String getHospitalName_hv() {
        return hospitalName_hv;
    }

    public void setHospitalName_hv(String hospitalName_hv) {
        this.hospitalName_hv = hospitalName_hv;
    }

    public String getEmail_hv() {
        return email_hv;
    }

    public void setEmail_hv(String email_hv) {
        this.email_hv = email_hv;
    }

    public String getPassword_hv() {
        return password_hv;
    }

    public void setPassword_hv(String password_hv) {
        this.password_hv = password_hv;
    }

    public String getPhone_hv() {
        return phone_hv;
    }

    public void setPhone_hv(String phone_hv) {
        this.phone_hv = phone_hv;
    }

    public String getLicenceNumber_hv() {
        return licenceNumber_hv;
    }

    public void setLicenceNumber_hv(String licenceNumber_hv) {
        this.licenceNumber_hv = licenceNumber_hv;
    }

    public String getReg_id_hv() {
        return reg_id_hv;
    }

    public void setReg_id_hv(String reg_id_hv) {
        this.reg_id_hv = reg_id_hv;
    }

    public String getDevice_type_hv() {
        return device_type_hv;
    }

    public void setDevice_type_hv(String device_type_hv) {
        this.device_type_hv = device_type_hv;
    }

    public String getLogin_type_hv() {
        return login_type_hv;
    }

    public void setLogin_type_hv(String login_type_hv) {
        this.login_type_hv = login_type_hv;
    }

    public String getLatitude_hv() {
        return latitude_hv;
    }

    public void setLatitude_hv(String latitude_hv) {
        this.latitude_hv = latitude_hv;
    }

    public String getLongitude_hv() {
        return longitude_hv;
    }

    public void setLongitude_hv(String longitude_hv) {
        this.longitude_hv = longitude_hv;
    }

    public String longitude_hv;


    public String getForgot_phone() {
        return forgot_phone;
    }

    public void setForgot_phone(String forgot_phone) {
        this.forgot_phone = forgot_phone;
    }

    public String getService_subcat_id() {
        return service_subcat_id;
    }

    public void setService_subcat_id(String service_subcat_id) {
        this.service_subcat_id = service_subcat_id;
    }

    public String getForgot_otp() {
        return forgot_otp;
    }

    public void setForgot_otp(String forgot_otp) {
        this.forgot_otp = forgot_otp;
    }

    public String getAbout() {
        return about;
    }

    public void setAbout(String about) {
        this.about = about;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getOtp() {
        return otp;
    }


    public void setOtp(String otp) {
        this.otp = otp;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getUserType() {
        return UserType;
    }

    public void setUserType(String userType) {
        UserType = userType;
    }


    public String getOtp_HV() {
        return otp_HV;
    }

    public void setOtp_HV(String otp_HV) {
        this.otp_HV = otp_HV;
    }


    public String getOtp_update_HV() {
        return otp_update_HV;
    }

    public void setOtp_update_HV(String otp_update_HV) {
        this.otp_update_HV = otp_update_HV;
    }

    public String getAddress_hv() {
        return address_hv;
    }

    public void setAddress_hv(String address_hv) {
        this.address_hv = address_hv;
    }

    public String getAbout_Hv() {
        return about_Hv;
    }

    public void setAbout_Hv(String about_Hv) {
        this.about_Hv = about_Hv;
    }


    public String getIcu_Bed_hv() {
        return icu_Bed_hv;
    }

    public void setIcu_Bed_hv(String icu_Bed_hv) {
        this.icu_Bed_hv = icu_Bed_hv;
    }

    public String getGeneralWard_Bed_hv() {
        return generalWard_Bed_hv;
    }

    public void setGeneralWard_Bed_hv(String generalWard_Bed_hv) {
        this.generalWard_Bed_hv = generalWard_Bed_hv;
    }

    private String driverName;

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getOfficialNum() {
        return officialNum;
    }

    public void setOfficialNum(String officialNum) {
        this.officialNum = officialNum;
    }

    public String getAmbulanceNum() {
        return ambulanceNum;
    }

    public void setAmbulanceNum(String ambulanceNum) {
        this.ambulanceNum = ambulanceNum;
    }

    public String getAmbulanceType() {
        return ambulanceType;
    }

    public void setAmbulanceType(String ambulanceType) {
        this.ambulanceType = ambulanceType;
    }

    public String getAmbulancePhoto() {
        return ambulancePhoto;
    }

    public void setAmbulancePhoto(String ambulancePhoto) {
        this.ambulancePhoto = ambulancePhoto;
    }


    public String getHospital_Photo() {
        return Hospital_Photo;
    }

    public void setHospital_Photo(String hospital_Photo) {
        Hospital_Photo = hospital_Photo;
    }

    public String Hospital_Photo;


    public String getPharmacyService_hv() {
        return PharmacyService_hv;
    }

    public void setPharmacyService_hv(String pharmacyService_hv) {
        PharmacyService_hv = pharmacyService_hv;
    }

    public String getDoctorUserID() {
        return doctorUserID;
    }

    public void setDoctorUserID(String doctorUserID) {
        this.doctorUserID = doctorUserID;
    }

    //    TODO: FOR DOCTOR VENDOR PART ««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««««

    public String DocName;
    public String DocEmail;
    public String DocPhone;
    public String DocAddress;
    public String DocLicenseNum;
    public String DocMCRNum;
    public String DocPass;
    public String DocPhoto;
    public String DocGender;
    public String DocSignaturePath;
    public String DocQualification;
    public String DocSpeciality;

    public String getDocQualification() {
        return DocQualification;
    }

    public void setDocQualification(String docQualification) {
        DocQualification = docQualification;
    }

    public String getDocSpeciality() {
        return DocSpeciality;
    }

    public void setDocSpeciality(String docSpeciality) {
        DocSpeciality = docSpeciality;
    }

    public String getDocName() {
        return DocName;
    }

    public void setDocName(String docName) {
        DocName = docName;
    }

    public String getDocEmail() {
        return DocEmail;
    }

    public void setDocEmail(String docEmail) {
        DocEmail = docEmail;
    }

    public String getDocPhone() {
        return DocPhone;
    }

    public void setDocPhone(String docPhone) {
        DocPhone = docPhone;
    }

    public String getDocAddress() {
        return DocAddress;
    }

    public void setDocAddress(String docAddress) {
        DocAddress = docAddress;
    }

    public String getDocLicenseNum() {
        return DocLicenseNum;
    }

    public void setDocLicenseNum(String docLicenseNum) {
        DocLicenseNum = docLicenseNum;
    }

    public String getDocMCRNum() {
        return DocMCRNum;
    }

    public void setDocMCRNum(String docMCRNum) {
        DocMCRNum = docMCRNum;
    }

    public String getDocPass() {
        return DocPass;
    }

    public void setDocPass(String docPass) {
        DocPass = docPass;
    }

    public String getDocPhoto() {
        return DocPhoto;
    }

    public void setDocPhoto(String docPhoto) {
        DocPhoto = docPhoto;
    }

    public String getDocGender() {
        return DocGender;
    }

    public void setDocGender(String docGender) {
        DocGender = docGender;
    }

    public String getDocSignaturePath() {
        return DocSignaturePath;
    }

    public void setDocSignaturePath(String docSignaturePath) {
        DocSignaturePath = docSignaturePath;
    }


}
