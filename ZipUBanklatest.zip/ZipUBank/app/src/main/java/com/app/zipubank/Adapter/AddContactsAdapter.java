package com.app.zipubank.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.zipubank.HomeActivities.Profile.Category.FamilyAccount.UnMatchedContacts;
import com.app.zipubank.R;
import com.app.zipubank.models.AddContactsModel;
import com.app.zipubank.models.GetContactsList;
import com.bumptech.glide.Glide;

import java.util.ArrayList;

import retrofit2.Callback;


public class AddContactsAdapter extends RecyclerView.Adapter<AddContactsAdapter.holder> {
    ArrayList<UnMatchedContacts.Detail> list;
    Context context;

    Callback callback;

    public AddContactsAdapter(ArrayList<UnMatchedContacts.Detail> list, Context context, Callback callback) {
        this.list = list;
        this.context = context;
        this.callback = callback;
    }

    @NonNull
    @Override
    public AddContactsAdapter.holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.add_contacts,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull AddContactsAdapter.holder holder, int position) {

        holder.text1.setText(list.get(position).getContactName());
        holder.number.setText(list.get(position).getNumber());
     //   Glide.with(context).load(list.get(position).getImage()).placeholder(R.drawable.zip_u_logo).into(holder.photo);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callback.callback(list.get(position));
            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class holder extends RecyclerView.ViewHolder {
        TextView text1;
        TextView number;
        ImageView photo;
        public holder(@NonNull View itemView) {
            super(itemView);
            text1 = itemView.findViewById(R.id.text1);
            number=itemView.findViewById(R.id.number);
      //      photo=itemView.findViewById(R.id.imageContact);

        }
    }
    public interface Callback{
        void callback(UnMatchedContacts.Detail detail);
    }
}
