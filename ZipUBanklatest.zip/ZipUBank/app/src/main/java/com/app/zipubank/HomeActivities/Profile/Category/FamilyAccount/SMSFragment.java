package com.app.zipubank.HomeActivities.Profile.Category.FamilyAccount;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;

import com.app.zipubank.R;

import com.app.zipubank.databinding.FragmentSMSBinding;
import com.app.zipubank.models.OtpModel;
import com.app.zipubank.retrofit.Mvvm;
import com.app.zipubank.utils.App;
import com.app.zipubank.utils.AppConstants;

import in.aabhasjindal.otptextview.OTPListener;
import in.aabhasjindal.otptextview.OtpTextView;

public class SMSFragment extends Fragment implements View.OnClickListener {
    FragmentSMSBinding binding;
    private AppCompatButton otp_button;
    private String phoneNumber = "", old_otp = "", new_otp = "", reg_id = "1234";
    private OtpTextView otpTextView;
    private TextView resend_code_tv, number_show;
    ImageView back;
    String phone;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentSMSBinding.inflate(getLayoutInflater());
        findId();

        Bundle bundle = getArguments();
        phone = bundle.getString("phone");
        Toast.makeText(requireContext(), "" + phone, Toast.LENGTH_SHORT).show();
        number_show.setText(phone);
        phoneNumber = App.getAppPreference().getStringValue(AppConstants.PHONE_NUMBER);
        old_otp = App.getAppPreference().getStringValue(AppConstants.OTP);

        Toast.makeText(getActivity(), "" + old_otp, Toast.LENGTH_SHORT).show();
        matchOtpFields();
        return binding.getRoot();
    }

    private void findId() {

        resend_code_tv = binding.resendCodeTv;
        resend_code_tv.setOnClickListener(this);
        otpTextView = binding.otpTextView;
        number_show = binding.numberShow;
        otp_button = binding.otpButton;
        back = binding.imgBackNew;
        otp_button.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        binding.imgBackNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requireActivity().onBackPressed();
            }
        });

        switch (view.getId()) {
            case R.id.otp_button:

                if (old_otp.equals(new_otp)) {
                    Navigation.findNavController(view).navigate(R.id.createPasswordFragment2);
                } else {
                    Toast.makeText(getActivity(), "otp is not match.", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.resend_code_tv:
                resendOtp();
                break;
        }
    }

    private void resendOtp() {
        new Mvvm().otpModelLiveData(getActivity(), phoneNumber).observe(getActivity(), new Observer<OtpModel>() {
            @Override
            public void onChanged(OtpModel map) {
                if (map.getSuccess().equalsIgnoreCase("1")) {

                    App.getAppPreference().saveStringValue(AppConstants.OTP, map.getOtp().toString());

                    old_otp = map.getOtp().toString();

                    Toast.makeText(getActivity(), "" + map.getOtp(), Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(getActivity(), "" + map.getMessage(), Toast.LENGTH_SHORT).show();

                }

            }
        });
    }

    private void matchOtpFields() {
        otpTextView.setOtpListener(new OTPListener() {
            @Override
            public void onInteractionListener() {
            }

            @Override
            public void onOTPComplete(String otp) {
                if (old_otp.equals(otp)) {

                    new_otp = otp;
                }
            }
        });
    }

}