package com.app.zipubank.HomeActivities.Expenses;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.app.zipubank.Adapter.DaysAdapter;
import com.app.zipubank.R;
import com.app.zipubank.databinding.FragmentExpensesBinding;

import org.jetbrains.annotations.NotNull;


public class ExpensesFragment extends Fragment {

FragmentExpensesBinding fragmentExpensesBinding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        fragmentExpensesBinding = FragmentExpensesBinding.inflate(getLayoutInflater());
        return fragmentExpensesBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        DaysAdapter daysAdapter = new DaysAdapter();
        fragmentExpensesBinding.recyclerViewDays.setAdapter(daysAdapter);
    }
    @Override
    public void onResume() {
        super.onResume();
        requireActivity().findViewById(R.id.bottom_nav).setVisibility(View.VISIBLE);
    }
}