package com.app.zipubank.models;

import java.io.Serializable;

public class BankStatusRoot implements Serializable {
    public String status;
    public String message;
    public BankStatusClass details;


    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public BankStatusClass getDetails() {
        return details;
    }

    public void setDetails(BankStatusClass details) {
        this.details = details;
    }
}
