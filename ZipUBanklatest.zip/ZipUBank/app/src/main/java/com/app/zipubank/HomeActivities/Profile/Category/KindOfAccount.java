package com.app.zipubank.HomeActivities.Profile.Category;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.app.zipubank.HomeActivity;
import com.app.zipubank.R;

import com.app.zipubank.databinding.FragmentKindOfAccountBinding;
import com.app.zipubank.utils.App;
import com.app.zipubank.utils.CommonUtil;

import org.jetbrains.annotations.NotNull;

public class KindOfAccount extends Fragment {

FragmentKindOfAccountBinding fragmentKindOfAccountBinding;
String accountType ;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        fragmentKindOfAccountBinding = FragmentKindOfAccountBinding.inflate(getLayoutInflater());

        onClicks();

        return fragmentKindOfAccountBinding.getRoot();
    }

    private void onClicks() {


        fragmentKindOfAccountBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requireActivity().onBackPressed();

            }
        });


        fragmentKindOfAccountBinding.personalAcc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                accountType = "1";
                App.getSingleton().setAccountType(accountType);

                Navigation.findNavController(fragmentKindOfAccountBinding.getRoot()).navigate(R.id.countryFragment);

            }
        });


        fragmentKindOfAccountBinding.familyAcc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                accountType = "2";
                App.getSingleton().setAccountType(accountType);

                Navigation.findNavController(fragmentKindOfAccountBinding.getRoot()).navigate(R.id.countryFragment);
            }
        });



        fragmentKindOfAccountBinding.businessAcc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                accountType = "3";
                App.getSingleton().setAccountType(accountType);

                Navigation.findNavController(fragmentKindOfAccountBinding.getRoot()).navigate(R.id.countryFragment);
            }
        });

    }

}