package com.app.zipubank.HomeActivities.Profile.Category.FamilyAccount;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import com.app.zipubank.R;
import com.app.zipubank.databinding.FragmentInternationalLocalBinding;
import com.app.zipubank.models.Currency.CurrencyRoot;
import com.app.zipubank.retrofit.Mvvm;
import com.app.zipubank.utils.CommonUtil;
import com.mynameismidori.currencypicker.CurrencyPicker;
import com.mynameismidori.currencypicker.CurrencyPickerListener;

import org.jetbrains.annotations.NotNull;

public class InternationalLocalFragment extends Fragment {
    FragmentInternationalLocalBinding fragmentInternationalLocalBinding;
    String clickCheck;
    private String start_country_code,end_country_code,amount = "";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        fragmentInternationalLocalBinding = FragmentInternationalLocalBinding.inflate(getLayoutInflater());
        return fragmentInternationalLocalBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        CurrencyPicker picker = CurrencyPicker.newInstance("Select Currency");

        fragmentInternationalLocalBinding.local.setBackgroundResource(R.drawable.transparent_round_design);
        fragmentInternationalLocalBinding.local.setTextColor(getResources().getColor(R.color.app_blue_color));
         fragmentInternationalLocalBinding.international.setBackgroundResource(R.drawable.transparent_round_design);
        fragmentInternationalLocalBinding.local.setTextColor(getResources().getColor(R.color.app_blue_color));

        fragmentInternationalLocalBinding.international.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickCheck = "1";
                fragmentInternationalLocalBinding.local.setBackgroundResource(R.drawable.transparent_round_design);
                fragmentInternationalLocalBinding.local.setTextColor(getResources().getColor(R.color.app_blue_color));
            }
        });
         fragmentInternationalLocalBinding.local.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fragmentInternationalLocalBinding.local.setBackgroundResource(R.drawable.transparent_round_design);
                fragmentInternationalLocalBinding.local.setTextColor(getResources().getColor(R.color.app_blue_color));
                clickCheck = "2";
            }
        });

        fragmentInternationalLocalBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requireActivity().onBackPressed();
            }
        });
        fragmentInternationalLocalBinding.continueInternational.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (start_country_code!=null && end_country_code!=null){
                    Bundle bundle=new Bundle();
                    if(getArguments() != null) {
                        bundle.putSerializable("bank", getArguments().getSerializable("bandData"));
                    }else {
                        Toast.makeText(requireContext(), "international data null", Toast.LENGTH_SHORT).show();
                    }

                    Navigation.findNavController(requireActivity(), R.id.nav_home).navigate(R.id.action_internationalLocalFragment_to_sendMoney,bundle);

                }else{
                    Toast.makeText(requireActivity(), "Enter Details", Toast.LENGTH_SHORT).show();
                }

            }
        });
        fragmentInternationalLocalBinding.startCountry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                amount = fragmentInternationalLocalBinding.enterAmount.getText().toString().trim();
                if (amount.length()==0){
                    fragmentInternationalLocalBinding.enterAmount.setError("Enter Amount");
                }
                else{
                    picker.setListener(new CurrencyPickerListener() {
                        @Override
                        public void onSelectCurrency(String name, String code, String symbol, int flagDrawableResID) {

                            start_country_code=code;
              //              Toast.makeText(requireActivity(), ""+start_country_code, Toast.LENGTH_SHORT).show();

                            fragmentInternationalLocalBinding.startCountryImage.setImageResource(flagDrawableResID);

                            picker.dismiss();

                            if(fragmentInternationalLocalBinding.enterAmount.getText().toString().length()!=0)
                            {
                                currencyConverter();
                            }

                        }
                    });
                    picker.show(requireActivity().getSupportFragmentManager(), "CURRENCY_PICKER");
                }
            }
        });

        fragmentInternationalLocalBinding.endCountryLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               try{
                CurrencyPicker picker = CurrencyPicker.newInstance("Select Currency");

                picker.setListener(new CurrencyPickerListener() {
                    @Override
                    public void onSelectCurrency(String name, String code, String symbol, int flagDrawableResID) {

                        end_country_code=code;

                        fragmentInternationalLocalBinding.endCountryImage.setImageResource(flagDrawableResID);

                        picker.dismiss();

                        if(fragmentInternationalLocalBinding.enterAmount.getText().toString().trim().length()!=0)
                        {
                            currencyConverter();
                        }
                    }
                });
                picker.show(requireActivity().getSupportFragmentManager(), "CURRENCY_PICKER");

            }catch (Exception e)
               {

               }
            }
        });

    }

    private void currencyConverter()
    {
        if (CommonUtil.isNetworkConnected(requireActivity())) {
            if (start_country_code==null){
                Toast.makeText(requireActivity(), "Select the country", Toast.LENGTH_SHORT).show();
            }
            else if (end_country_code==null){
                Toast.makeText(requireActivity(), "Select the country", Toast.LENGTH_SHORT).show();
            }
            else{
                setApiData();
            }
        } else {
            Toast.makeText(requireActivity(), "No Internet Connection", Toast.LENGTH_SHORT).show();
        }
    }

    private void setApiData() {
        Log.d("getAmont", "setApiData: "+ start_country_code + "," +end_country_code+ "," +fragmentInternationalLocalBinding.enterAmount.getText().toString().trim());
        new Mvvm().currencyRootLiveData(requireActivity(),start_country_code,end_country_code,
                fragmentInternationalLocalBinding.enterAmount.getText().toString().trim()).observe(requireActivity(),
                new Observer<CurrencyRoot>() {
                    @Override
                    public void onChanged(CurrencyRoot currencyRoot) {
                        if (currencyRoot.getSuccess().equalsIgnoreCase("1")){
                            CommonUtil.dismissProgress();
              //              Toast.makeText(requireActivity(), ""+currencyRoot.getSuccess(), Toast.LENGTH_SHORT).show();



                            fragmentInternationalLocalBinding.currentAmount.setText(currencyRoot.getDetails().getAmount()+ " " + currencyRoot.getDetails().getBase());
                            fragmentInternationalLocalBinding.rate.setText((currencyRoot.getDetails().getResult().getRate())+ " "+ currencyRoot.getDetails().getBase());
//                            Log.d("currency", "onChanged: "+String.valueOf(currencyRoot.getMyvar().getConstant()));
                            ReviewDetailsFragment.detailCurrency = currencyRoot;
                            SendMoney.currency = currencyRoot;
                            fragmentInternationalLocalBinding.convertedAmount.setText(String.valueOf(currencyRoot.getVar().getConstant()));

                        }
                        else{
                            Toast.makeText(requireActivity(), ""+currencyRoot.getSuccess(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    @Override
    public void onResume() {
        super.onResume();
        requireActivity().findViewById(R.id.bottom_nav).setVisibility(View.GONE);
    }
}