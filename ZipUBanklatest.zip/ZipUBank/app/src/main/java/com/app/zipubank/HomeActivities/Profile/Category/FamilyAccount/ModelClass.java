package com.app.zipubank.HomeActivities.Profile.Category.FamilyAccount;

public class ModelClass {
    private String bank_name;
    private String bank_img;

    public ModelClass(String bank_name, String bank_img) {
        this.bank_name = bank_name;
        this.bank_img = bank_img;
    }

    public String getBank_name() {
        return bank_name;
    }

    public void setBank_name(String bank_name) {
        this.bank_name = bank_name;
    }

    public String getBank_img() {
        return bank_img;
    }

    public void setBank_img(String bank_img) {
        this.bank_img = bank_img;
    }
}
