package com.app.zipubank.HomeActivities.Home.AddMoney;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.app.zipubank.R;
import com.app.zipubank.databinding.FragmentAccountBinding;
import com.app.zipubank.databinding.FragmentAddMoneyBinding;
import com.app.zipubank.models.BankStatusRoot;
import com.app.zipubank.retrofit.Mvvm;
import com.app.zipubank.utils.CommonUtil;
import com.bumptech.glide.Glide;
import com.google.android.material.navigation.NavigationView;

import org.jetbrains.annotations.NotNull;

import java.util.NavigableMap;


public class AddMoneyFragment extends Fragment {
    FragmentAddMoneyBinding fragmentAddMoneyBinding;
    public static String amount,wallet_id;;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        fragmentAddMoneyBinding = FragmentAddMoneyBinding.inflate(getLayoutInflater());
        return fragmentAddMoneyBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        new Mvvm().bankStatusRootLiveData(requireActivity(), CommonUtil.getUserId()).observe(requireActivity(), new Observer<BankStatusRoot>() {
            @Override
            public void onChanged(BankStatusRoot bankStatusRoot) {
                if (bankStatusRoot.getStatus().equals("1")){
                    fragmentAddMoneyBinding.bankBalance.setText("You have "+bankStatusRoot.getDetails().getWallet_amount() +" "+ bankStatusRoot.getDetails().getCountry_name());
                    Glide.with(requireContext()).load(bankStatusRoot.getDetails().getCountryDetails().getImage()).into(fragmentAddMoneyBinding.countryImage);
                    fragmentAddMoneyBinding.countryName.setText(bankStatusRoot.getDetails().getCountry_name());
                    wallet_id = bankStatusRoot.getDetails().getWalletId();
                }
                else{
                    Toast.makeText(requireActivity(), ""+bankStatusRoot.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });


        fragmentAddMoneyBinding.continueAddMoney.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (fragmentAddMoneyBinding.getAmount.getText().toString().length()==0){
                    Toast.makeText(requireContext(), "Enter Amount", Toast.LENGTH_SHORT).show();
                }
                else{
                    amount = fragmentAddMoneyBinding.getAmount.getText().toString();
                    Navigation.findNavController(requireActivity(),R.id.nav_home).navigate(R.id.action_addMoneyFragment_to_chooseAnAccountFragment);
                }
            }
        });
    }
    @Override
    public void onResume() {
        super.onResume();
        requireActivity().findViewById(R.id.bottom_nav).setVisibility(View.GONE);
    }
}