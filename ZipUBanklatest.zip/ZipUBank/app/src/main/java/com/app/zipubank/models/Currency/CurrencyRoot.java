package com.app.zipubank.models.Currency;

import java.io.Serializable;

public class CurrencyRoot implements Serializable {

    public String success;
    public String message;
    public CurrencyClass details;
    public Var var;

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public CurrencyClass getDetails() {
        return details;
    }

    public void setDetails(CurrencyClass details) {
        this.details = details;
    }

    public Var getVar() {
        return var;
    }

    public void setVar(Var var) {
        this.var = var;
    }
}
