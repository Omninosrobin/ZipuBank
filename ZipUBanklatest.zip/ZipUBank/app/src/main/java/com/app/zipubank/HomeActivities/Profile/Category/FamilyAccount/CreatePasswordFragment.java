package com.app.zipubank.HomeActivities.Profile.Category.FamilyAccount;

import static android.content.ContentValues.TAG;
import static com.app.zipubank.splashScreenFragment.SplashScreen.latitude;
import static com.app.zipubank.splashScreenFragment.SplashScreen.longitude;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;

import com.app.zipubank.HomeActivity;
import com.app.zipubank.databinding.FragmentCreatePasswordBinding;
import com.app.zipubank.models.RegisterModel;
import com.app.zipubank.retrofit.Mvvm;
import com.app.zipubank.utils.App;
import com.app.zipubank.utils.AppConstants;
import com.app.zipubank.utils.CommonUtil;

public class CreatePasswordFragment extends Fragment {
    FragmentCreatePasswordBinding fragmentCreatePasswordBinding;
    String email, accountType="", country, state, phone, password;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        fragmentCreatePasswordBinding = FragmentCreatePasswordBinding.inflate(getLayoutInflater());
        onClicks();

        return fragmentCreatePasswordBinding.getRoot();
    }

    public String getDeviceName() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;
        if (model.toLowerCase().startsWith(manufacturer.toLowerCase())) {
            return capitalize(model);
        } else {
            return capitalize(manufacturer) + " " + model;
        }
    }

    private String capitalize(String s) {
        if (s == null || s.length() == 0) {
            return "";
        }
        char first = s.charAt(0);
        if (Character.isUpperCase(first)) {
            return s;
        } else {
            return Character.toUpperCase(first) + s.substring(1);
        }
    }

    private Boolean validatePassword() {
        String val = fragmentCreatePasswordBinding.newPassword.getText().toString();
        String passwordVal = "^" +
                //at least 1 upper case letter
                "(?=.*[a-zA-Z])" +      //any letter
                "(?=.*[@#$%^&+=])" +    //at least 1 special character
                "(?=\\S+$)" +           //no white spaces
                ".{4,}" +               //at least 4 characters
                "$";
        if (val.isEmpty()) {
            fragmentCreatePasswordBinding.newPassword.setError("Field cannot be empty");
            return false;
        } else if (!val.matches(passwordVal)) {
            fragmentCreatePasswordBinding.newPassword.setError("Password is too weak");
            return false;
        } else {
            fragmentCreatePasswordBinding.newPassword.setError(null);
            return true;
        }
    }

    private void onClicks() {

        fragmentCreatePasswordBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requireActivity().onBackPressed();
            }
        });

        fragmentCreatePasswordBinding.donePassword.setOnClickListener(view -> {

            email = App.getSingleton().getDocEmail();
            accountType = App.getSingleton().getAccountType();
            country = App.getSingleton().getCountryName();
            state = App.getSingleton().getStateName();
            phone = App.getSingleton().getPhone();

            Log.d("onClicks", ""+email);
            Log.d("onClicks", ""+accountType);
            Log.d("onClicks", ""+country);
            Log.d("onClicks", ""+state);
            Log.d("onClicks", ""+phone);
            Log.d("onClicks", ""+getDeviceName());
            Log.d("onClicks", ""+getDeviceName());
            Log.d("onClicks", ""+latitude);
            Log.d("onClicks", ""+longitude);
            Log.d("onClicks", ""+accountType);
            password = fragmentCreatePasswordBinding.newPassword.getText().toString();

            if (!validatePassword()) {
                return;

            } else {
                if (fragmentCreatePasswordBinding.newPassword.getText().length()>16){
                    Toast.makeText(requireActivity(), "Password Too long", Toast.LENGTH_SHORT).show();
                }
                else{

                    new Mvvm().registerModelLiveData(requireActivity(), phone, email, password, getDeviceName(), "user", "android", String.valueOf(latitude), String.valueOf(longitude), "", accountType, country, state).observe(requireActivity(), new Observer<RegisterModel>() {
                        @Override
                        public void onChanged(RegisterModel registerModel) {
                            if (registerModel.getSuccess().equalsIgnoreCase("1")) {
                                App.getAppPreference().saveStringValue(AppConstants.LOGIN_STATUS, "0");
                                App.getAppPreference().saveStringValue(AppConstants.USER_ID, registerModel.getDetails().getId());
                                App.getAppPreference().saveModel(AppConstants.USER_DETAILS, registerModel);
                                App.getAppPreference().saveStringValue(AppConstants.USER_NAME, registerModel.getDetails().getName());
                                App.getAppPreference().saveStringValue(AppConstants.ACCOUNT_STATUS, registerModel.getDetails().getAccount_status());
                                App.getAppPreference().saveStringValue(AppConstants.USER_PHONE_NUMBER, registerModel.getDetails().getPhoneNumber());
                                App.getAppPreference().saveStringValue(AppConstants.USER_EMAIL, registerModel.getDetails().getEmail());

                                Intent intent = new Intent(getActivity(), HomeActivity.class);
                                startActivity(intent);

                                Log.d(TAG, "onChanged: " + CommonUtil.getUserId());

                            }
                            Toast.makeText(getActivity(), "" + registerModel.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }

        });
    }

}