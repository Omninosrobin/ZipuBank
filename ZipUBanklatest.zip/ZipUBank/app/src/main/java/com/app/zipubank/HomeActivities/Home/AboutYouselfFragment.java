package com.app.zipubank.HomeActivities.Home;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;

import com.app.zipubank.R;

import com.app.zipubank.databinding.FragmentAboutYouselfBinding;
import com.app.zipubank.models.AccountRoot;
import com.app.zipubank.models.CountryClass;
import com.app.zipubank.models.CountryRoot;
import com.app.zipubank.retrofit.Mvvm;
import com.app.zipubank.utils.CommonUtil;
import com.app.zipubank.utils.RealPathUtil;
import com.github.dhaval2404.imagepicker.ImagePicker;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class AboutYouselfFragment extends Fragment {
    FragmentAboutYouselfBinding binding;
    String country_text, name_text, username_text, date_text, month_text, year_text, address_text, city_text, province_text, dateOfBirth, stringPhotoPath;
    public  static int checkNumb = 0;
    String country, state,countryNameString;
    public static String country_code,country_img;
    ArrayList<String> countryListRoots = new ArrayList<>();
    ArrayList<CountryClass> list = new ArrayList<>();
    Uri imageUriPhotos;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentAboutYouselfBinding.inflate(getLayoutInflater());
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.showImage.setImageURI(imageUriPhotos);

        new Mvvm().countryRootLiveData(requireActivity()).observe(requireActivity(), new Observer<CountryRoot>() {
            @Override
            public void onChanged(CountryRoot countryRoot) {
                if (countryRoot.getSuccess().equalsIgnoreCase("1")){
                    Toast.makeText(requireContext(), ""+countryRoot.getMessage(), Toast.LENGTH_SHORT).show();
                    list = countryRoot.getDetails();
                    setSpinnerAdapter(list);

                }
                else{
                    Toast.makeText(requireContext(), ""+countryRoot.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });


        binding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requireActivity().onBackPressed();
            }
        });

        binding.uploadLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int permission = ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_EXTERNAL_STORAGE);
                if (permission != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2);
                } else {
                    Intent intent = new Intent(Intent.ACTION_PICK);
                    intent.setType("image/*");
                    startActivityForResult(intent, 2);
                }
            }
        });
        binding.faceScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkNumb = 1;
              //  ImagePicker.Companion.with(AboutYouselfFragment.this).cameraOnly().compress(1024).maxResultSize(1080, 1080).start();

                Navigation.findNavController(requireActivity(), R.id.nav_home).navigate(R.id.action_aboutYouselfFragment_to_scanningFaceFragment);
            }
        });

        binding.doneSomeOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                name_text = binding.enterName.getText().toString();
                username_text = binding.enterUsername.getText().toString();
                date_text = binding.enterDate.getText().toString();
                month_text = binding.enterMonth.getText().toString();
                year_text = binding.enterYear.getText().toString();
                address_text = binding.enterAddress.getText().toString();
                city_text = binding.enterCity.getText().toString();
                province_text = binding.enterProvince.getText().toString();
                dateOfBirth = date_text + " / " + month_text + " / " + year_text;

                if (countryNameString == null){
                    Toast.makeText(requireContext(), "Select Country", Toast.LENGTH_SHORT).show();
                }
                else if (name_text.length() == 0) {
                    binding.enterName.setError("Enter Name");
                    binding.enterName.requestFocus();
                } else if (username_text.length() == 0) {
                    binding.enterUsername.setError("Enter UserName");
                    binding.enterUsername.requestFocus();
                } else if (date_text.length() == 0) {
                    binding.enterDate.setError("Enter Date");
                    binding.enterDate.requestFocus();
                } else if (month_text.length() == 0) {
                    binding.enterMonth.setError("Enter Month");
                    binding.enterMonth.requestFocus();
                } else if (year_text.length() == 0) {
                    binding.enterYear.setError("Enter Year");
                    binding.enterYear.requestFocus();
                } else if (address_text.length() == 0) {
                    binding.enterAddress.setError("Enter Address");
                    binding.enterAddress.requestFocus();
                } else if (city_text.length() == 0) {
                    binding.enterCity.setError("Enter City");
                    binding.enterCity.requestFocus();
                } else if (province_text.length() == 0) {
                    binding.enterProvince.setError("Enter Province");
                    binding.enterProvince.requestFocus();
                }
                else if(checkNumb==0){
                    Toast.makeText(requireContext(), "Scan Your Face", Toast.LENGTH_SHORT).show();
                }
               else {
                    new Mvvm().CreateAccountMutableLiveData(requireActivity(), CommonUtil.getRequestBodyText(countryNameString), CommonUtil.getRequestBodyText(name_text),CommonUtil.getRequestBodyText(username_text), CommonUtil.getRequestBodyText(dateOfBirth),
                                    CommonUtil.getRequestBodyText(address_text), CommonUtil.getRequestBodyText(province_text),
                                    CommonUtil.getRequestBodyText(city_text),CommonUtil.getRequestBodyText(""), CommonUtil.getFileData(stringPhotoPath, "face_image"),
                                    CommonUtil.getFileData(stringPhotoPath, "document_image"),CommonUtil.getRequestBodyText(CommonUtil.getUserId()))
                            .observe(requireActivity(), new Observer<AccountRoot>() {
                                @Override
                                public void onChanged(AccountRoot accountRoot) {
                                    if (accountRoot.getSuccess().equalsIgnoreCase("1")) {
                               //         Toast.makeText(requireContext(), "" + accountRoot.getMessage(), Toast.LENGTH_SHORT).show();
                      //                  Toast.makeText(requireContext(), ""+countryNameString, Toast.LENGTH_SHORT).show();
                                        Navigation.findNavController(binding.getRoot()).navigate(R.id.action_aboutYouselfFragment_to_viewBankDetail);
                                    } else {
                                        Toast.makeText(requireContext(), "" + accountRoot.getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                }
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode,
                                 @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {

            assert data != null;
            imageUriPhotos = data.getData();
            stringPhotoPath = RealPathUtil.getRealPath(requireActivity(), imageUriPhotos);
            binding.showImage.setImageURI(imageUriPhotos);

       //     Toast.makeText(getContext(), stringPhotoPath, Toast.LENGTH_SHORT).show();
            binding.uploadLayout.setVisibility(View.GONE);
            binding.showLayout.setVisibility(View.VISIBLE);

        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull @NotNull String[] permissions, @NonNull @NotNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
    private void setSpinnerAdapter(ArrayList<CountryClass> list) {
        countryListRoots.clear();
        countryListRoots.add("Select Country");
        for (int i = 0 ; i <list.size();i++){
            countryListRoots.add(list.get(i).getCountryName());

        }
        ArrayAdapter<String> adp2 = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, countryListRoots);
        adp2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.countryName.setAdapter(adp2);
        adp2.notifyDataSetChanged();
        binding.countryName.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (i==0){
                    countryNameString = null;
                }
                else{
                    countryNameString = countryListRoots.get(i);
                    country_code = list.get(i-1).getCountryCode();
                    country_img = list.get(i-1).getImage();
//                    Toast.makeText(requireContext(), ""+countryNameString, Toast.LENGTH_SHORT).show();
//                    Toast.makeText(requireContext(), ""+country_img, Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {


            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        countryNameString=null;
    }
}