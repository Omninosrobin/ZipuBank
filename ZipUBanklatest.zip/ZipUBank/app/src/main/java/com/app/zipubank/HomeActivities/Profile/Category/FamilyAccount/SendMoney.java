package com.app.zipubank.HomeActivities.Profile.Category.FamilyAccount;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.app.zipubank.R;
import com.app.zipubank.databinding.FragmentSendMoneyBinding;
import com.app.zipubank.models.Currency.CurrencyRoot;
import com.app.zipubank.models.Receipt.SomeoneElse.SomeoneElseGetRoot;
import com.app.zipubank.utils.App;
import com.app.zipubank.utils.AppPreferences;

public class SendMoney extends Fragment {
    FragmentSendMoneyBinding sendMoneyBinding;
    public static CurrencyRoot currency;
    public static SomeoneElseGetRoot bankUserData;
    public static SomeoneElseGetRoot.Detail detail;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        sendMoneyBinding = FragmentSendMoneyBinding.inflate(getLayoutInflater());

        return sendMoneyBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setdata();

        Toast.makeText(requireContext(), ""+detail.getHolderAccountName().toString(), Toast.LENGTH_SHORT).show();
    }

    private void setdata() {

        sendMoneyBinding.holderNames.setText(detail.getHolderAccountName());
        sendMoneyBinding.accNumber.setText(detail.getBankAccopuntNumber());
        sendMoneyBinding.statusName.setText(detail.getHolderAccountName());
        sendMoneyBinding.moneySend.setText(String.valueOf(currency.getVar().getConstant()));

    }

    @Override
    public void onResume() {

        super.onResume();
        requireActivity().findViewById(R.id.bottom_nav).setVisibility(View.GONE);
    }
}