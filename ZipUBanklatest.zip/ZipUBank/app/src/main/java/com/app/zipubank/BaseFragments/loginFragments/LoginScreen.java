package com.app.zipubank.BaseFragments.loginFragments;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.Toast;

import com.app.zipubank.HomeActivity;
import com.app.zipubank.MainActivity;
import com.app.zipubank.R;
import com.app.zipubank.databinding.FragmentLoginScreenBinding;
import com.app.zipubank.models.NewPassword;
import com.app.zipubank.models.OtpForgotpass;
import com.app.zipubank.models.RegisterModel;
import com.app.zipubank.retrofit.ApiInterface;
import com.app.zipubank.retrofit.Mvvm;
import com.app.zipubank.utils.App;
import com.app.zipubank.utils.AppConstants;
import com.chaos.view.PinView;

import in.aabhasjindal.otptextview.OtpTextView;


public class LoginScreen extends Fragment {
    FragmentLoginScreenBinding loginScreenBinding;
    String userEmail, password;

   @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        loginScreenBinding=FragmentLoginScreenBinding.inflate(getLayoutInflater());


        onClicks();


        return loginScreenBinding.getRoot();
    }

    private void onClicks() {

       loginScreenBinding.signUp.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Navigation.findNavController(loginScreenBinding.getRoot()).navigate(R.id.action_loginScreen_to_enterEmailFragment2);
           }
       });
        loginScreenBinding.login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                logInUser();
            }
        });
        loginScreenBinding.textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                forgotPassword();

            }
        });
    }

    private void forgotPassword() {
        final Dialog dialog = new Dialog(requireActivity());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.forgotemailadressdailog);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        AppCompatButton next = dialog.findViewById(R.id.next);
        EditText ed_email = dialog.findViewById(R.id.email_edit);
        next.setOnClickListener(view -> {

            String email = ed_email.getText().toString().trim();

            if (email.isEmpty()) {

                ed_email.setError("Enter your email");
                ed_email.requestFocus();

            } else {
            new Mvvm().otpForgotpassLiveData(requireActivity(),email).observe(requireActivity(), new Observer<OtpForgotpass>() {
                @Override
                public void onChanged(OtpForgotpass otpForgotpass) {
                    if (otpForgotpass!=null){
                        if (otpForgotpass.getSuccess().equalsIgnoreCase("1")){
                     //       Toast.makeText(requireContext(), "otp"+otpForgotpass.getOtp(), Toast.LENGTH_SHORT).show();

                            dialog.dismiss();

                            optPassword(dialog, otpForgotpass.getOtp());

                        }else{
                            Toast.makeText(requireContext(), "0"+otpForgotpass.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(requireContext(), "Root is null", Toast.LENGTH_SHORT).show();
                    }

                }

            });

            }
        });
        dialog.show();

    }

    private void optPassword(Dialog dialog, String otp) {
        final Dialog dialog2 = new Dialog(requireActivity());
        dialog2.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog2.setCancelable(true);
        dialog2.setContentView(R.layout.forgotpassworddailogbox);
        dialog2.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        AppCompatButton done = dialog2.findViewById(R.id.submit_Btn);
        PinView otpTextView = dialog2.findViewById(R.id.pinView);


        done.setOnClickListener(view -> {
            String oldOtp = otpTextView.getText().toString();

            if (oldOtp.equals(String.valueOf(otp))) {
                dialog.dismiss();
                newPassword(dialog2);

            } else {
                Toast.makeText(requireContext(), "invalid Otp!", Toast.LENGTH_SHORT).show();
            }

        });
        dialog2.show();
    }



    private void newPassword(Dialog dialog2) {

        final Dialog dialog3 = new Dialog(requireActivity());
        dialog3.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog3.setCancelable(true);
        dialog3.setContentView(R.layout.confirm_forgot_password);
        dialog3.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        AppCompatButton done = dialog3.findViewById(R.id.done);
        EditText edit_email = dialog3.findViewById(R.id.et_email);
        EditText new_password = dialog3.findViewById(R.id.new_password);
        EditText confirm_password = dialog3.findViewById(R.id.confirm_password);

        dialog3.show();


        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String email = edit_email.getText().toString().trim();
                String newPassword = new_password.getText().toString().trim();
                String confirmPassword = confirm_password.getText().toString().trim();



                if (email.isEmpty()) {

                    edit_email.setError("Enter your email");
                    edit_email.requestFocus();

                } else if (newPassword.isEmpty()) {

                    new_password.setError("Enter a new password");
                    new_password.requestFocus();

                } else if (!newPassword.equals(confirmPassword)) {

                    confirm_password.setError("password not matched");
                    confirm_password.requestFocus();

                }

                new Mvvm().newPasswordLiveData(requireActivity(), email,newPassword).observe(requireActivity(), new Observer<NewPassword>() {
                    @Override
                    public void onChanged(NewPassword rootRegister) {

                        if (rootRegister.getSuccess().equals("1")) {

            //                Toast.makeText(requireContext(), "" + rootRegister.getMessage(), Toast.LENGTH_SHORT).show();

                            dialog3.dismiss();
                            startActivity(new Intent(requireActivity(), MainActivity.class));
                            requireActivity().finish();


                        } else {
                            Toast.makeText(requireContext(), "" + rootRegister.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }

                });
            }
        });
        dialog3.show();
    }

    private void logInUser() {

       userEmail = loginScreenBinding.username.getText().toString();
       password = loginScreenBinding.password.getText().toString();

        if (userEmail.isEmpty())
        {
            loginScreenBinding.username.setError("field can't be empty");
        }else if (password.isEmpty())
        {
            loginScreenBinding.password.setError("field can't be empty");
        }else {
            new Mvvm().loginData(requireActivity(), userEmail, password).observe(requireActivity(), new Observer<RegisterModel>() {
                @Override
                public void onChanged(RegisterModel registerModel) {
                    if (registerModel.getSuccess().equalsIgnoreCase("1"))
                    {
                        App.getAppPreference().saveStringValue(AppConstants.LOGIN_STATUS,"0");
              //          Toast.makeText(requireContext(), ""+registerModel.getDetails().getId(), Toast.LENGTH_SHORT).show();
                        App.getAppPreference().saveStringValue(AppConstants.USER_ID,registerModel.getDetails().getId());
                        App.getAppPreference().saveModel(AppConstants.USER_DETAILS,registerModel);
                        App.getAppPreference().saveStringValue(AppConstants.USER_NAME,registerModel.getDetails().getName());
                        App.getAppPreference().saveStringValue(AppConstants.USER_PHONE_NUMBER,registerModel.getDetails().getPhoneNumber());
                        App.getAppPreference().saveStringValue(AppConstants.USER_EMAIL,registerModel.getDetails().getEmail());

                        startActivity(new Intent(requireActivity(), HomeActivity.class));
                        requireActivity().finish();

             //           Toast.makeText(getActivity(), ""+registerModel.getMessage(), Toast.LENGTH_SHORT).show();

                    }

                    else {
                        Toast.makeText(getActivity(), ""+registerModel.getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            });
        }

    }


}