package com.app.zipubank.retrofit;

import android.telecom.PhoneAccount;

import com.app.zipubank.HomeActivities.Profile.Category.FamilyAccount.UnMatchedContacts;
import com.app.zipubank.models.AccountRoot;
import com.app.zipubank.models.AccountStatusRoot;
import com.app.zipubank.models.BankListRoot;
import com.app.zipubank.models.BankStatusRoot;
import com.app.zipubank.models.CardDetailsRoot;
import com.app.zipubank.models.CountryRoot;
import com.app.zipubank.models.Currency.CurrencyRoot;
import com.app.zipubank.models.GetContactsList;
import com.app.zipubank.models.GetMyBankDetail;
import com.app.zipubank.models.LogoutModel;
import com.app.zipubank.models.NewPassword;
import com.app.zipubank.models.OtpForgotpass;
import com.app.zipubank.models.OtpModel;
import com.app.zipubank.models.Receipt.SomeoneElse.SomeoneElseGetRoot;
import com.app.zipubank.models.Receipt.SomeoneElse.SomeoneElseRoot;
import com.app.zipubank.models.RegisterModel;
import com.app.zipubank.models.ShowCardDetailRoot;
import com.app.zipubank.models.UserBankDetailRoot;
import com.google.gson.JsonObject;

import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface ApiInterface {

    @FormUrlEncoded
    @POST("userRegister")
    Call<RegisterModel> userRegister(
            @Field("phoneNumber") String phoneNumber,
            @Field("email") String email,
            @Field("password") String password,
            @Field("device_type") String device_type,
            @Field("login_type") String login_type,
            @Field("device_id") String device_id,
            @Field("latitude") String latitude,
            @Field("longitude") String longitude,
            @Field("reg_id") String reg_id,
            @Field("accountType") String accountType,
            @Field("country") String country,
            @Field("state") String state);

    @FormUrlEncoded
    @POST("userLogin")
    Call<RegisterModel> userLogin(@Field("useremail") String useremail,
                                  @Field("password") String password);


    @FormUrlEncoded
    @POST("ValidPhone")
    Call<OtpModel> validPhone(@Field("phone") String useremail);

    @FormUrlEncoded
    @POST("getUserBankDetails")
    Call<GetMyBankDetail> getAddMyBankAccount(@Field("userId") String userId);

    @FormUrlEncoded
    @POST("addMyBankAccount")
    Call<OtpModel> addMyBankAccount(@Field("userId") String userid, @Field("username") String username,
                                    @Field("iban") String iban, @Field("bank_name") String bank_name, @Field("image") String bank_image);

    @FormUrlEncoded
    @POST("userLogout")
    Call<LogoutModel> logoutUser
            (@Field("userId") String userId);

    @Multipart
    @POST("updateUserProfile")
    Call<RegisterModel> updateUser(@Part("name") RequestBody name,
                                   @Part("gender") RequestBody gender,
                                   @Part("dob") RequestBody dob,
                                   @Part("latitude") RequestBody latitude,
                                   @Part("longitude") RequestBody longitude,
                                   @Part("id") RequestBody id,
                                   @Part MultipartBody.Part profileImage);

    @Multipart
    @POST("userBankAccount")
    Call<AccountRoot> createUserAccount(@Part("country_name") RequestBody country_name,
                                        @Part("first_name") RequestBody first_name,
                                        @Part("last_name") RequestBody last_name,
                                        @Part("dob") RequestBody dob,
                                        @Part("address") RequestBody address,
                                        @Part("document_name") RequestBody document_name,
                                        @Part("city") RequestBody city,
                                        @Part("accountStatus") RequestBody accountStatus,
                                        @Part MultipartBody.Part face_image,
                                        @Part MultipartBody.Part document_image,
                                        @Part("userId") RequestBody userId);

    @GET("getCountryFlags")
    Call<CountryRoot> getCountryList();

    @FormUrlEncoded
    @POST("getAccountStatus")
    Call<AccountStatusRoot> getAccountStatus(@Field("id") String id);

    @FormUrlEncoded
    @POST("getWalletAmount")
    Call<BankStatusRoot> getBankAcccountStatus(@Field("userId") String userId);

    @FormUrlEncoded
    @POST("addWalletAmount")
    Call<Map> addMoneyToWallet(@Field("userId") String userId, @Field("walletId") String walletId
            , @Field("wallet_amount") String wallet_amount, @Field("type") String type);

    @FormUrlEncoded
    @POST("addCard")
    Call<CardDetailsRoot> addCard(@Field("userId") String userId, @Field("cardNumber") String cardNumber,
                                  @Field("name") String name,
                                  @Field("cvv") String cvv, @Field("expiryYear") String expiryYear,
                                  @Field("expiryMonth") String expiryMonth, @Field("cardType") String cardType);


    @FormUrlEncoded
    @POST("getCard")
    Call<ShowCardDetailRoot> getCard(@Field("userId") String userId);

    @FormUrlEncoded
    @POST("removeCard")
    Call<Map> removeCard(@Field("userId") String userId, @Field("id") String id);

    @GET("bankList")
    Call<BankListRoot> getBankList();

    @FormUrlEncoded
    @POST("currencyConverter")
    Call<CurrencyRoot> currencyConverter(@Field("from") String from,
                                         @Field("to") String to,
                                         @Field("amount") String amount);

    @FormUrlEncoded
    @POST("addRecipientMyself")
    Call<SomeoneElseRoot> someoneElseReceipt(@Field("userId") String userId, @Field("recipientType") String recipientType,
                                             @Field("email") String email, @Field("holderAccountName") String holderAccountName,
                                             @Field("bankAccopuntNumber") String bankAccopuntNumber, @Field("country") String country,
                                             @Field("city") String city, @Field("address") String address,
                                             @Field("zipcode") String zipcode, @Field("bankCode") String bankCode);

    @FormUrlEncoded
    @POST("getRecipients")
    Call<SomeoneElseGetRoot> getSomeoneElseReceipt(@Field("userId") String userId);


    // add user contacts
//    @FormUrlEncoded
//    @POST("addUserContacts")
//    Call<AddContactsModel> addUserContacts(@Field("userId") String userId,
//                                           @Field("contact_num") String contact_num);


    @POST("addUserContacts")
    Call<Map> userContact(@Body JsonObject jsonArray) ;


    //  Forgot password

    @FormUrlEncoded
    @POST("forgetPassword")
    Call<OtpForgotpass> forgetPassword(
            @Field("email") String email);

    // NEw Password
    @FormUrlEncoded
    @POST("changePassword")
    Call<NewPassword>changePassword(
            @Field("email")String email,
            @Field("password")String password);

    @FormUrlEncoded
    @POST("getUserContacts")
    Call<GetContactsList>getUserContacts(@Field("userId")String userId);

    @FormUrlEncoded
    @POST("getUnMatchedUserContacts")
    Call<UnMatchedContacts>getUnMatchedUserContacts(@Field("userId")String userId);

    @FormUrlEncoded
    @POST("getuserBankAccount")
    Call<UserBankDetailRoot>getuserBankAccount(@Field("userId")String userId);

}
