package com.app.zipubank.HomeActivities.Profile.Category.FamilyAccount;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.app.zipubank.R;
import com.app.zipubank.databinding.FragmentMyselfBinding;
import com.app.zipubank.models.BankListClass;
import com.app.zipubank.models.BankListRoot;
import com.app.zipubank.models.GetMyBankDetail;
import com.app.zipubank.models.OtpModel;
import com.app.zipubank.retrofit.Mvvm;
import com.app.zipubank.utils.CommonUtil;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class MyselfFragment extends Fragment {
    FragmentMyselfBinding fragmentMyselfBinding;
    private List<BankListClass> self_bank_list;
    private List<String> bank_name;
    private List<String> bank_img;
    String name;
    String image;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        fragmentMyselfBinding = FragmentMyselfBinding.inflate(getLayoutInflater());
        return fragmentMyselfBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        self_bank_list = new ArrayList<>();
        bank_name = new ArrayList<>();
        bank_img = new ArrayList<>();

        fragmentMyselfBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requireActivity().onBackPressed();
            }
        });
        fragmentMyselfBinding.newAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (fragmentMyselfBinding.name.getText().toString().length()==0){
                    fragmentMyselfBinding.name.setError("Enter Name");
                    fragmentMyselfBinding.name.requestFocus();
                }
                else if (fragmentMyselfBinding.accountNumber.getText().length()==0){
                    fragmentMyselfBinding.accountNumber.setError("Enter Account Number");
                    fragmentMyselfBinding.accountNumber.requestFocus();
                }
                else if (name.length()==0){
                    Toast.makeText(requireContext(), "Select Bank", Toast.LENGTH_SHORT).show();
                }
                else{
                    Log.d("userid", "onClick: "+ CommonUtil.getUserId());
                    new Mvvm().addMyBankAccountLive(requireActivity(),CommonUtil.getUserId(),fragmentMyselfBinding.name.getText().toString(),fragmentMyselfBinding.accountNumber.getText().toString(),name,image).observe(requireActivity(), new Observer<OtpModel>() {
                        @Override
                        public void onChanged(OtpModel otpModel) {
                            if (otpModel.getMessage().equalsIgnoreCase("1")){
                                Toast.makeText(requireContext(), ""+ otpModel.getMessage(), Toast.LENGTH_SHORT).show();
                                Navigation.findNavController(fragmentMyselfBinding.getRoot()).navigate(R.id.action_myselfFragment_to_sendingReceiptFragment);
                            }
                            else{
                                Toast.makeText(requireContext(), ""+ otpModel.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });

        new Mvvm().bankListRootLiveData(requireActivity()).observe(requireActivity(), new Observer<BankListRoot>() {
            @Override
            public void onChanged(BankListRoot bankListRoot) {
                if (bankListRoot.getStatus().equalsIgnoreCase("1")){
                    self_bank_list = bankListRoot.getDetails();
                    setSpinnerAdapter(self_bank_list);
                }
                else{
                    Toast.makeText(requireContext(), ""+bankListRoot.getDetails(), Toast.LENGTH_SHORT).show();
                }
            }
        });


//        setAdapter();
    }

    private void setSpinnerAdapter(List<BankListClass> self_bank_list) {
        bank_name.clear();
        for (int i = 0; i < self_bank_list.size(); i++) {
            bank_name.add(self_bank_list.get(i).getBankName());
            bank_img.add(self_bank_list.get(i).getBankImage());
        }

        ArrayAdapter<String> adp2 = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, bank_name);
        adp2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fragmentMyselfBinding.bankDetail.setAdapter(adp2);
        fragmentMyselfBinding.bankDetail.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                name  = bank_name.get(i);
                image  = bank_img.get(i);
                Toast.makeText(requireContext(), "" + name, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                Toast.makeText(requireContext(), "Select Category", Toast.LENGTH_SHORT).show();
            }
        });

    }

//    private void setAdapter() {
//        new Mvvm().getAddMyBankAccountLive(requireActivity(), CommonUtil.getUserId()).observe(requireActivity(), new Observer<GetMyBankDetail>() {
//            @Override
//            public void onChanged(GetMyBankDetail getMyBankDetail) {
//                if (getMyBankDetail.getSuccess().equalsIgnoreCase("1")){
//
//                    fragmentMyselfBinding.emptyText.setVisibility(View.GONE);
//                    fragmentMyselfBinding.myselfBankDetails.setVisibility(View.VISIBLE);
//
//                    self_bank_list = getMyBankDetail.getDetails();
//                    MyselfAccuntDetailsAdapter myselfAccuntDetailsAdapter = new MyselfAccuntDetailsAdapter(self_bank_list);
//                    fragmentMyselfBinding.myselfBankDetails.setAdapter(myselfAccuntDetailsAdapter);
//
//                    Toast.makeText(requireContext(), ""+getMyBankDetail.getMessage(), Toast.LENGTH_SHORT).show();
//                }
//                else{
//
//                    fragmentMyselfBinding.emptyText.setVisibility(View.VISIBLE);
//                    fragmentMyselfBinding.myselfBankDetails.setVisibility(View.GONE);
//
//                    Toast.makeText(requireContext(), ""+getMyBankDetail.getMessage(), Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
//    }
}