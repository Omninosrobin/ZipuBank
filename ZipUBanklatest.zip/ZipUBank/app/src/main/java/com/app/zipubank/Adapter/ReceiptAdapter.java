package com.app.zipubank.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.zipubank.R;
import com.app.zipubank.models.Receipt.ReceiptClass;
import com.app.zipubank.models.Receipt.SomeoneElse.SomeoneElseGetClass;
import com.app.zipubank.models.Receipt.SomeoneElse.SomeoneElseGetRoot;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class ReceiptAdapter extends RecyclerView.Adapter<ReceiptAdapter.ViewHolder> {
//    private ArrayList<> receipt_list;

    public ReceiptAdapter(ArrayList<SomeoneElseGetClass> receipt_list) {
//        this.receipt_list = receipt_list;
    }

    @NonNull
    @Override
    public ReceiptAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.recepit_list,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ReceiptAdapter.ViewHolder holder, int position) {
//        holder.recipt_name.setText(receipt_list.get(position).getHolderAccountName());
//        holder.receipt_country.setText(receipt_list.get(position).getCountry());
    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView recipt_name,receipt_country;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            recipt_name = itemView.findViewById(R.id.recipt_name);
            receipt_country = itemView.findViewById(R.id.receipt_country);
        }
    }
}
