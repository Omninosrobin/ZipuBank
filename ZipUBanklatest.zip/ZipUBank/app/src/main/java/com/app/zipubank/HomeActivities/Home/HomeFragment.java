package com.app.zipubank.HomeActivities.Home;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.compose.runtime.snapshots.Snapshot;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SnapHelper;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.app.zipubank.Adapter.TransactionsAdapter;
import com.app.zipubank.HomeActivities.Home.ChooseAccount.ChooseAnAccountFragment;
import com.app.zipubank.HomeActivities.Home.getStarted.DayFragment;
import com.app.zipubank.HomeActivities.Home.getStarted.MonthFragment;
import com.app.zipubank.HomeActivities.Home.getStarted.WeekFragment;
import com.app.zipubank.HomeActivities.Home.getStarted.YearFragment;
import com.app.zipubank.R;


import com.app.zipubank.databinding.FragmentHomeBinding;
import com.app.zipubank.models.AccountStatusRoot;
import com.app.zipubank.models.AddContactsModel;
import com.app.zipubank.models.BankStatusRoot;
import com.app.zipubank.retrofit.Mvvm;
import com.app.zipubank.utils.App;
import com.app.zipubank.utils.AppConstants;
import com.app.zipubank.utils.CommonUtil;
import com.bumptech.glide.Glide;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class HomeFragment extends Fragment {
    private TabLayout tablayout_ExploreScreen;
    private ViewPager viewPager_ES;
          RecyclerView transaction;
    FragmentHomeBinding fragmentHomeBinding;
    int status;
    ArrayList<AddContactsModel> list = new ArrayList<>();
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        fragmentHomeBinding = FragmentHomeBinding.inflate(getLayoutInflater());

        status = AboutYouselfFragment.checkNumb;

        return fragmentHomeBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        findId(view);
        tabLayoutMethod();
        checkPermission();
        adapterTransaction();
        new Mvvm().accountStatusRootLiveData(requireActivity(), CommonUtil.getUserId()).observe(requireActivity(), new Observer<AccountStatusRoot>() {
            @Override
            public void onChanged(AccountStatusRoot accountStatusRoot) {
                if (accountStatusRoot.getStatus().equalsIgnoreCase("1")){
                    if (accountStatusRoot.getDetails().getAccount_status().equalsIgnoreCase("0")){
                        fragmentHomeBinding.openAccount.setVisibility(View.VISIBLE);
                        fragmentHomeBinding.addMoneyLayout.setVisibility(View.GONE);
                        fragmentHomeBinding.pendingLayout.setVisibility(View.GONE);
                    }
                    else if (accountStatusRoot.getDetails().getAccount_status().equalsIgnoreCase("1")){
                        fragmentHomeBinding.openAccount.setVisibility(View.GONE);
                        fragmentHomeBinding.addMoneyLayout.setVisibility(View.VISIBLE);
                        fragmentHomeBinding.pendingLayout.setVisibility(View.GONE);
                    }
                    else{
                        Toast.makeText(requireContext(), "error", Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                //    Toast.makeText(requireContext(), ""+accountStatusRoot.getMessage(), Toast.LENGTH_SHORT).show();
                }

            }
        });

        new Mvvm().bankStatusRootLiveData(requireActivity(), CommonUtil.getUserId()).observe(requireActivity(), new Observer<BankStatusRoot>() {
            @Override
            public void onChanged(BankStatusRoot bankStatusRoot) {
                if (bankStatusRoot.getStatus().equals("1")){
                    fragmentHomeBinding.amount.setText("$ "+ bankStatusRoot.getDetails().getWallet_amount());
                    fragmentHomeBinding.nameAmount.setText(bankStatusRoot.getDetails().getCountry_name() + " Dollar");
                    Glide.with(requireContext()).load(bankStatusRoot.getDetails().getCountryDetails().getImage()).into(fragmentHomeBinding.flag);
                }
                else{
                    Toast.makeText(requireActivity(), ""+bankStatusRoot.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });

//        else if (App.getAppPreference().getStringValue(AppConstants.ACCOUNT_STATUS).equalsIgnoreCase("1")){
//            fragmentHomeBinding.openAccount.setVisibility(View.GONE);
//            fragmentHomeBinding.addMoneyLayout.setVisibility(View.GONE);
//            fragmentHomeBinding.pendingLayout.setVisibility(View.VISIBLE);
//            fragmentHomeBinding.reject.setText("Your request \n is Pending");
//            fragmentHomeBinding.pending.setImageResource(R.drawable.ic_baseline_alarm_24);
//        }
//        else if (App.getAppPreference().getStringValue(AppConstants.ACCOUNT_STATUS).equalsIgnoreCase("2")){
//            fragmentHomeBinding.openAccount.setVisibility(View.GONE);
//            fragmentHomeBinding.addMoneyLayout.setVisibility(View.VISIBLE);
//            fragmentHomeBinding.pendingLayout.setVisibility(View.GONE);
//
//        }
//        else if (App.getAppPreference().getStringValue(AppConstants.ACCOUNT_STATUS).equalsIgnoreCase("3")){
//            fragmentHomeBinding.openAccount.setVisibility(View.GONE);
//            fragmentHomeBinding.addMoneyLayout.setVisibility(View.GONE);
//            fragmentHomeBinding.pendingLayout.setVisibility(View.VISIBLE);
//            fragmentHomeBinding.pending.setImageResource(R.drawable.ic_baseline_error_outline_24);
//            fragmentHomeBinding.reject.setText("Your Account has\n been rejected");
//        }

//        fragmentHomeBinding.checkAcBalance.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Navigation.findNavController(requireActivity(),R.id.nav_home).navigate(R.id.action_homeFragment_to_checkBalance2);
//
//            }
//        });
        fragmentHomeBinding.openAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(requireActivity(),R.id.nav_home).navigate(R.id.action_homeFragment_to_getStartedFragment);
            }
        });

        fragmentHomeBinding.addMoneyLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(requireActivity(),R.id.nav_home).navigate(R.id.action_homeFragment_to_addMoneyFragment);
            }
        });

    }

    private void tabLayoutMethod() {

        tablayout_ExploreScreen.addTab(tablayout_ExploreScreen.newTab().setText("Day"));
        tablayout_ExploreScreen.addTab(tablayout_ExploreScreen.newTab().setText("Week"));
        tablayout_ExploreScreen.addTab(tablayout_ExploreScreen.newTab().setText("Month"));
        tablayout_ExploreScreen.addTab(tablayout_ExploreScreen.newTab().setText("Year"));

        tablayout_ExploreScreen.setTabGravity(TabLayout.GRAVITY_FILL);


        final PagerAdapter pagerAdapter= new Adaptor(getChildFragmentManager(),tablayout_ExploreScreen.getTabCount());
        viewPager_ES.setAdapter(pagerAdapter);
        viewPager_ES.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tablayout_ExploreScreen));
        tablayout_ExploreScreen.addOnTabSelectedListener(new TabLayout.ViewPagerOnTabSelectedListener(viewPager_ES));
        animationApplier(tablayout_ExploreScreen);

    }

    private void animationApplier(TabLayout tabLayout) {

        tabLayout.setTranslationY(300);
        tabLayout.setAlpha(0);
        tabLayout.animate().translationY(0).alpha(1).setDuration(500).setStartDelay(100).start();
    }
    public static class Adaptor extends FragmentStatePagerAdapter
    {

        private final int totalCount;

        public Adaptor(@NonNull FragmentManager fm, int behavior) {
            super(fm, behavior);

            this.totalCount=behavior;
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {

            switch (position)
            {
                case 0:
                    return new DayFragment();
                case 1:
                    return new WeekFragment();
                case 2:
                    return new MonthFragment();
                case 3:
                    return new YearFragment();

                default:
                    return null;
            }
        }

        @Override
        public int getCount() {
            return totalCount;
        }
    }

    private void findId(View view) {
        tablayout_ExploreScreen=view.findViewById(R.id.tablayout_ExploreScreen);
        viewPager_ES=view.findViewById(R.id.viewPager_ES);

    }


    private void checkPermission() {
        if (ContextCompat.checkSelfPermission(requireActivity(), Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(requireActivity(), new String[]{Manifest.permission.READ_CONTACTS}, 100);
        } else {
            getContactList();
        }

    }

    private void getContactList() {
        //        Uri uri= ContactsContract.Contacts.CONTENT_URI;
//        String sort=ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME+"ASC";
        Cursor cursor = requireActivity().getContentResolver().query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);

        //Cursor cursor=getContentResolver().query(uri,null,null,null,sort
        // );
        if (cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                @SuppressLint("Range") String id = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));
                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                Uri uriPhone = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
                String selection = ContactsContract.CommonDataKinds.Phone.CONTACT_ID + "=?";

                Cursor phoneCursor = requireActivity().getContentResolver().query(uriPhone, null, selection, new String[]{id}, null);
                if (phoneCursor.moveToNext()) {
                    @SuppressLint("Range") String number = phoneCursor.getString(phoneCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                    AddContactsModel model = new AddContactsModel();

                    model.setName(name);
                    model.setContact_num(number);

                    list.add(model);
                    phoneCursor.close();
                }


            }
            cursor.close();
        }
        AddContactsApi();
//        phone.setLayoutManager(new LinearLayoutManager(requireActivity()));
//        AddContactsAdapter adapters = new AddContactsAdapter(list, requireActivity());
//        phone.setAdapter(adapters);

    }

    private void AddContactsApi() {
        JsonObject obj = new JsonObject();

        obj.add("userContact",  ApiJsonMap(list));
        obj.addProperty("userId", CommonUtil.getUserId());

//        Toast.makeText(requireContext(), ""+ApiJsonMap(list), Toast.LENGTH_SHORT).show();

        new Mvvm().addContactsModelLiveData(requireActivity(),obj).observe(requireActivity(), new Observer<Map>() {
            @Override
            public void onChanged(Map map) {

                Toast.makeText(requireContext(), ""+map.get("message"), Toast.LENGTH_SHORT).show();

            }
        });
    }

    private JsonArray ApiJsonMap(List<AddContactsModel> contactsInfoList) {
        JsonArray JsonArray = new JsonArray();


        for (int i = 0; i<contactsInfoList.size(); i++) {
            JsonObject jsonObj_ = new JsonObject();

            contactsInfoList.get(i).getName().replace("/'","");
            jsonObj_.addProperty("name",contactsInfoList.get(i).getName());
            jsonObj_.addProperty("number", contactsInfoList.get(i).getContact_num());

            JsonArray.add(jsonObj_);
        }

        return JsonArray;
    }


    @Override
    public void onResume() {
        super.onResume();
        requireActivity().findViewById(R.id.bottom_nav).setVisibility(View.VISIBLE);
    }
    private void adapterTransaction() {
        TransactionsAdapter transactionsAdapter=new TransactionsAdapter();
    //    fragmentHomeBinding.transactionRec.setAdapter(transactionsAdapter);
    }
}