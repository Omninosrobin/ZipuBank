package com.app.zipubank.models;

public class AccountStatusClass {
    public String account_status;

    public String getAccount_status() {
        return account_status;
    }

    public void setAccount_status(String account_status) {
        this.account_status = account_status;
    }
}
