package com.app.zipubank.HomeActivities.Profile.Category.FamilyAccount;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.app.zipubank.R;
import com.app.zipubank.databinding.FragmentFamilyBinding;
import com.app.zipubank.models.Receipt.SomeoneElse.SomeoneElseRoot;
import com.app.zipubank.retrofit.Mvvm;
import com.app.zipubank.utils.CommonUtil;

public class FamilyFragment extends Fragment {
    FragmentFamilyBinding familyBinding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
     familyBinding=FragmentFamilyBinding.inflate(getLayoutInflater());
     return familyBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        familyBinding.doneSomeOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

        //        recieptApi();
            }
        });
    }

    private void recieptApi() {

//        String email = familyBinding.enterEmail.getText().toString();
//        String name = familyBinding.enterHolderName.getText().toString();
//        String iban = familyBinding.enterIban.getText().toString();
//        String country = familyBinding.enterCountry.getText().toString();
//        String city = familyBinding.enterCity.getText().toString();
//        String address = familyBinding.enterAddress.getText().toString();
//        String zipcode = familyBinding.enterZipCode.getText().toString();
//
//        if (email.length()==0){
//            familyBinding.enterEmail.setError("Enter Email");
//            familyBinding.enterEmail.requestFocus();
//        }
//        else if (name.length()==0){
//            familyBinding.enterHolderName.setError("Enter Email");
//            familyBinding.enterHolderName.requestFocus();
//        }
//        else if (iban.length()==0){
//            familyBinding.enterIban.setError("Enter Email");
//            familyBinding.enterIban.requestFocus();
//        }
//        else if (country.length()==0){
//            familyBinding.enterCountry.setError("Enter Email");
//            familyBinding.enterCountry.requestFocus();
//        }
//        else if (city.length()==0){
//            familyBinding.enterCity.setError("Enter Email");
//            familyBinding.enterCity.requestFocus();
//        }
//        else if (address.length()==0){
//            familyBinding.enterAddress.setError("Enter Email");
//            familyBinding.enterAddress.requestFocus();
//        }
//        else if (zipcode.length()==0){
//            familyBinding.enterZipCode.setError("Enter Email");
//            familyBinding.enterZipCode.requestFocus();
//        }
//        else{
//            new Mvvm().someoneElseRootLiveData(requireActivity(), CommonUtil.getUserId(),"2",email,name,
//                    iban,country,city,address,zipcode,"").observe(requireActivity(), new Observer<SomeoneElseRoot>() {
//                @Override
//                public void onChanged(SomeoneElseRoot someoneElseRoot) {
//                    if (someoneElseRoot.getStatus().equals("1")){
//                        Bundle bundle = new Bundle();
//                        bundle.putString("email",familyBinding.enterEmail.getText().toString());
//                        bundle.putString("iban",familyBinding.enterIban.getText().toString());
//                        bundle.putString("code",familyBinding.enterZipCode.getText().toString());
//                        bundle.putString("name",familyBinding.enterHolderName.getText().toString());
//                        Navigation.findNavController(requireActivity(), R.id.nav_home).navigate(R.id.action_someoneElseFragment_to_reviewDetailsFragment,bundle);
//                        Toast.makeText(requireActivity(), ""+someoneElseRoot.getMessage(), Toast.LENGTH_SHORT).show();
//                    }
//                    else{
//                        Toast.makeText(requireActivity(), ""+someoneElseRoot.getMessage(), Toast.LENGTH_SHORT).show();
//                    }
//                }
//            });
//        }
    }
}