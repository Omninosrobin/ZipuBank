package com.app.zipubank.HomeActivities.Profile.Category.FamilyAccount;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.provider.ContactsContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.app.zipubank.Adapter.AddContactsAdapter;
import com.app.zipubank.R;
import com.app.zipubank.models.AddContactsModel;
import com.app.zipubank.models.GetContactsList;
import com.app.zipubank.retrofit.ApiInterface;
import com.app.zipubank.retrofit.BaseUrlRetrofit;
import com.app.zipubank.retrofit.Mvvm;
import com.app.zipubank.utils.CommonUtil;
import com.github.dhaval2404.imagepicker.BuildConfig;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class AddContactFragment extends Fragment implements AddContactsAdapter.Callback{
    RecyclerView phone;
  ArrayList<UnMatchedContacts.Detail> list;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add_contact, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        phone = view.findViewById(R.id.recycler);
        apiGetContacts();
    }

    private void apiGetContacts() {
        new Mvvm().unMatchedContactsLiveData(requireActivity(),CommonUtil.getUserId()).observe(requireActivity(), new Observer<UnMatchedContacts>() {
            @Override
            public void onChanged(UnMatchedContacts unMatchedContacts) {

                if (unMatchedContacts.getSuccess().equalsIgnoreCase("1")){

                    list=unMatchedContacts.getDetails();
            //        Toast.makeText(requireContext(), "Contacts List"+unMatchedContacts.getMessage(), Toast.LENGTH_SHORT).show();
                    AddContactsAdapter addContactsAdapter=new AddContactsAdapter(list,requireContext(),AddContactFragment.this);
                    phone.setAdapter(addContactsAdapter);

                }else {
                    Toast.makeText(requireContext(), "Problem in model", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }


    @Override
    public void callback(UnMatchedContacts.Detail detail) {
        if (detail != null) {

                String number = detail.getNumber();// The number on which you want to send SMS
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.fromParts("sms", number, null)));
//            try {
//                Intent shareIntent = new Intent(Intent.ACTION_SEND);
//                shareIntent.setType("text/plain");
//                shareIntent.putExtra(Intent.EXTRA_SUBJECT, "My application name");
//                String shareMessage = "\nHey! join this app for easy money transfer\n\n";
//                shareMessage = shareMessage + "https://drive.google.com/file/d/1uGaun0-6U_uqut49VhphlVf7CRatJIv5/view?usp=share_link" + BuildConfig.APPLICATION_ID + "\n\n";
//                shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
//
//                startActivity(Intent.createChooser(shareIntent, "choose one"));
//            } catch (Exception e) {
//
//            }

        }
    }
}
