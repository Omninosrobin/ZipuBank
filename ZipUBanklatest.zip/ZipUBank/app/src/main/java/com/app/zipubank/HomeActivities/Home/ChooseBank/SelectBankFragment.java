
package com.app.zipubank.HomeActivities.Home.ChooseBank;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.app.zipubank.Adapter.BankListAdapter;
import com.app.zipubank.R;
import com.app.zipubank.databinding.FragmentSelectBankBinding;
import com.app.zipubank.models.BankListClass;
import com.app.zipubank.models.BankListRoot;
import com.app.zipubank.retrofit.Mvvm;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class SelectBankFragment extends Fragment {
    FragmentSelectBankBinding fragmentSelectBankBinding;
    ArrayList<BankListClass> bankList;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        fragmentSelectBankBinding = FragmentSelectBankBinding.inflate(getLayoutInflater());
        return fragmentSelectBankBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

//        fragmentSelectBankBinding.selectBank.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Navigation.findNavController(requireActivity(),R.id.nav_home).navigate(R.id.action_selectBankFragment_to_getStartedFragment);
//            }
//        });

        new Mvvm().bankListRootLiveData(requireActivity()).observe(requireActivity(), new Observer<BankListRoot>() {
            @Override
            public void onChanged(BankListRoot bankListRoot) {
                if (bankListRoot.getStatus().equalsIgnoreCase("1")){
                    Toast.makeText(requireContext(), ""+bankListRoot.getMessage(), Toast.LENGTH_SHORT).show();
                    bankList = new ArrayList<>();
                    bankList = bankListRoot.getDetails();
                    BankListAdapter bankListAdapter = new BankListAdapter(bankList, new BankListAdapter.CallbackClick() {
                        @Override
                        public void onClick(int position) {
                            Navigation.findNavController(requireActivity(),R.id.nav_home).navigate(R.id.action_selectBankFragment_to_homeFragment);
                        }
                    },requireContext());
                    fragmentSelectBankBinding.selectBankRecycler.setAdapter(bankListAdapter);
                }
                else{
                    Toast.makeText(requireContext(), ""+bankListRoot.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}