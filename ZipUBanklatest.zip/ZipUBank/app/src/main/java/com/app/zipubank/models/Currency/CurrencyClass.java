package com.app.zipubank.models.Currency;

import com.app.zipubank.models.Currency.CurrencyResult;

import java.io.Serializable;

public class CurrencyClass implements Serializable {
    public String base;
    public int amount;
    public CurrencyResult result;
    public int ms;

    public String getBase() {
        return base;
    }

    public void setBase(String base) {
        this.base = base;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public CurrencyResult getResult() {
        return result;
    }

    public void setResult(CurrencyResult result) {
        this.result = result;
    }

    public int getMs() {
        return ms;
    }

    public void setMs(int ms) {
        this.ms = ms;
    }


}
