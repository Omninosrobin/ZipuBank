package com.app.zipubank.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.app.zipubank.R;
import com.app.zipubank.models.GetContactsList;
import com.bumptech.glide.Glide;

import java.util.ArrayList;

import retrofit2.Callback;

public class ZipuUserContactList extends RecyclerView.Adapter<ZipuUserContactList.holder> {
    ArrayList<GetContactsList.Details.Contact> list;
    Context context;
    Callback callback;

    public ZipuUserContactList(ArrayList<GetContactsList.Details.Contact> list, Context context,Callback callback) {
        this.list = list;
        this.context = context;
        this.callback = callback;
    }

    @NonNull
    @Override
    public ZipuUserContactList.holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.zipu_users_contcts,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ZipuUserContactList.holder holder, int position) {
        Glide.with(context).load(list.get(position).getProfileImage()).placeholder(R.drawable.bank_one).into(holder.imageUSer);

        holder.nameUser.setText(list.get(position).getContactName());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callback.callback(list.get(position));
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class holder extends RecyclerView.ViewHolder {
        ImageView imageUSer;
        TextView nameUser;
        RelativeLayout rel;

        public holder(@NonNull View itemView) {
            super(itemView);
            imageUSer=itemView.findViewById(R.id.imageUserContacts);
            nameUser=itemView.findViewById(R.id.nameUserContacts);
            rel=itemView.findViewById(R.id.relativeContacts);

        }

    }
    public interface Callback{
        void callback(GetContactsList.Details.Contact contact);
    }

}
