package com.app.zipubank.models.Receipt.SomeoneElse;

import java.io.Serializable;

public class SomeoneElseGetClass implements Serializable {
    public String id;
    public String userId;
    public String recipientId;
    public String email;
    public String holderAccountName;
    public String bankAccopuntNumber;
    public String country;
    public String city;
    public String address;
    public String zipcode;
    public String bankCode;
    public String created;
    public String updated;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getRecipientId() {
        return recipientId;
    }

    public void setRecipientId(String recipientId) {
        this.recipientId = recipientId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getHolderAccountName() {
        return holderAccountName;
    }

    public void setHolderAccountName(String holderAccountName) {
        this.holderAccountName = holderAccountName;
    }

    public String getBankAccopuntNumber() {
        return bankAccopuntNumber;
    }

    public void setBankAccopuntNumber(String bankAccopuntNumber) {
        this.bankAccopuntNumber = bankAccopuntNumber;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    public String getUpdated() {
        return updated;
    }

    public void setUpdated(String updated) {
        this.updated = updated;
    }
}
