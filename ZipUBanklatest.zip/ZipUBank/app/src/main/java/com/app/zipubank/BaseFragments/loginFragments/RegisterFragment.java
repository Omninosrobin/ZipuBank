package com.app.zipubank.BaseFragments.loginFragments;

import static com.app.zipubank.splashScreenFragment.SplashScreen.latitude;
import static com.app.zipubank.splashScreenFragment.SplashScreen.longitude;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.app.zipubank.HomeActivity;
import com.app.zipubank.MainActivity;
import com.app.zipubank.R;
import com.app.zipubank.databinding.FragmentRegisterBinding;
import com.app.zipubank.models.RegisterModel;
import com.app.zipubank.retrofit.Mvvm;
import com.app.zipubank.utils.App;
import com.app.zipubank.utils.AppConstants;

public class RegisterFragment extends Fragment {
    FragmentRegisterBinding binding;
    String username, email, phone, password, confirmPassword;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentRegisterBinding.inflate(inflater, container, false);

        binding.signUp.setOnClickListener(view -> {

            registerUser();

        });

        return binding.getRoot();
    }
    public String getDeviceName() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;
        if (model.toLowerCase().startsWith(manufacturer.toLowerCase())) {
            return capitalize(model);
        } else {
            return capitalize(manufacturer) + " " + model;
        }
    }


    private String capitalize(String s) {
        if (s == null || s.length() == 0) {
            return "";
        }
        char first = s.charAt(0);
        if (Character.isUpperCase(first)) {
            return s;
        } else {
            return Character.toUpperCase(first) + s.substring(1);
        }
    }

    private void registerUser() {

        username = binding.userName.getText().toString();
        email = binding.email.getText().toString();
        phone = binding.phone.getText().toString();
        password = binding.password.getText().toString();
        confirmPassword = binding.confPassword.getText().toString();

        if (username.isEmpty())
        {
            binding.userName.setError("field can't be empty");
        }else if (email.isEmpty())
        {
            binding.email.setError("field can't be empty");
        }else if (phone.isEmpty())
        {
            binding.phone.setError("field can't be empty");

        }else if (password.isEmpty())
        {
            binding.password.setError("field can't be empty");

        }else if (confirmPassword.isEmpty())
        {
            binding.confPassword.setError("field can't be empty");

        }else if (password.compareTo(confirmPassword)!=0)
        {
            Toast.makeText(requireActivity(), "Password and Confirm password Should be Same !", Toast.LENGTH_SHORT).show();
        }else {

//            new Mvvm().registerModelLiveData(requireActivity(), username, phone, email, password, getDeviceName(), "user", "1234", String.valueOf(latitude), String.valueOf(longitude), "12345").observe(requireActivity(), new Observer<RegisterModel>() {
//                @Override
//                public void onChanged(RegisterModel registerModel) {
//                    if (registerModel.getSuccess()!=null){
//                        if (registerModel.getSuccess().equalsIgnoreCase("1"))
//                        {
//                            App.getAppPreference().saveStringValue(AppConstants.LOGIN_STATUS,"0");
//                            App.getAppPreference().saveStringValue(AppConstants.USER_ID,registerModel.getDetails().getId());
//                            App.getAppPreference().saveModel(AppConstants.USER_DETAILS,registerModel.getDetails());
//                            App.getAppPreference().saveStringValue(AppConstants.USER_NAME,registerModel.getDetails().getUserName());
//                            App.getAppPreference().saveStringValue(AppConstants.USER_PHONE_NUMBER,registerModel.getDetails().getPhoneNumber());
//                            App.getAppPreference().saveStringValue(AppConstants.USER_EMAIL,registerModel.getDetails().getEmail());
//
//                            Intent intent=new Intent(getActivity(), HomeActivity.class);
//                            startActivity(intent);
//
//                            Toast.makeText(getActivity(), ""+registerModel.getMessage(), Toast.LENGTH_SHORT).show();
//
//                        }
//
//                        else {
//                            Toast.makeText(getActivity(), ""+registerModel.getMessage(), Toast.LENGTH_SHORT).show();
//                        }
//                    }
//
//
//                }
    //        });

        }

    }
}