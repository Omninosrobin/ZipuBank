package com.app.zipubank.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.zipubank.R;

import org.jetbrains.annotations.NotNull;

public class DaysAdapter extends RecyclerView.Adapter<DaysAdapter.ViewHolder> {

    @NonNull
    @NotNull
    @Override
    public DaysAdapter.ViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.days_list,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull DaysAdapter.ViewHolder holder, int position) {


    }

    @Override
    public int getItemCount() {

        return 7;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public ViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
        }
    }
}
