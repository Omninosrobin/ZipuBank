package com.app.zipubank.models.Currency;

import java.io.Serializable;

public class CurrencyResult implements Serializable {
    public double eUR;
    public double rate;

    public double geteUR() {
        return eUR;
    }

    public void seteUR(double eUR) {
        this.eUR = eUR;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }
}
