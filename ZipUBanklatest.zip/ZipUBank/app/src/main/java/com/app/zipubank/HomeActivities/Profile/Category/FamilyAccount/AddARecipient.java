package com.app.zipubank.HomeActivities.Profile.Category.FamilyAccount;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.app.zipubank.R;
import com.app.zipubank.databinding.FragmentAddARecipientBinding;


import org.jetbrains.annotations.NotNull;

public class AddARecipient extends Fragment {

    FragmentAddARecipientBinding fragmentAddARecipientBinding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        fragmentAddARecipientBinding = FragmentAddARecipientBinding.inflate(getLayoutInflater());
        return fragmentAddARecipientBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        fragmentAddARecipientBinding.myselfOpen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(requireActivity(), R.id.nav_home).navigate(R.id.action_addARecipient_to_myselfFragment);
            }
        });

        fragmentAddARecipientBinding.someoneElse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(requireActivity(), R.id.nav_home).navigate(R.id.action_addARecipient_to_someoneElseFragment);
            }
        });
        fragmentAddARecipientBinding.familyRll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
        Navigation.findNavController(requireActivity(), R.id.nav_home).navigate(R.id.familyFragment);
            }
        });



    }
}