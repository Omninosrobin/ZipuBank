package com.app.zipubank;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.navigation.Navigation;

import com.app.zipubank.databinding.ActivityHomeBinding;
import com.app.zipubank.models.AddContactsModel;

import java.util.ArrayList;

public class HomeActivity extends AppCompatActivity {

   public static ActivityHomeBinding homeBinding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        homeBinding = ActivityHomeBinding.inflate(getLayoutInflater());
        setContentView(homeBinding.getRoot());

        homeBinding.bottomNav.send.setOnClickListener(view -> {
            Navigation.findNavController(HomeActivity.this,R.id.nav_home).navigate(R.id.sendingReceiptFragment);
        });

        homeBinding.bottomNav.homeClick.setOnClickListener(view -> {

            colorText(homeBinding.bottomNav.museumImg,homeBinding.bottomNav.expensesImg,homeBinding.bottomNav.accountImg,homeBinding.bottomNav.profileImg,homeBinding.bottomNav.museumText,homeBinding.bottomNav.expensesText,homeBinding.bottomNav.accountText,homeBinding.bottomNav.profileText);

            Navigation.findNavController(HomeActivity.this,R.id.nav_home).navigate(R.id.homeFragment);
        });
        homeBinding.bottomNav.expensesClick.setOnClickListener(view -> {
            colorText(homeBinding.bottomNav.expensesImg,homeBinding.bottomNav.museumImg,homeBinding.bottomNav.accountImg,homeBinding.bottomNav.profileImg,homeBinding.bottomNav.expensesText,homeBinding.bottomNav.museumText,homeBinding.bottomNav.accountText,homeBinding.bottomNav.profileText);

            Navigation.findNavController(HomeActivity.this,R.id.nav_home).navigate(R.id.expensesFragment);

        });
        homeBinding.bottomNav.accountClick.setOnClickListener(view -> {

            colorText(homeBinding.bottomNav.accountImg,homeBinding.bottomNav.museumImg,homeBinding.bottomNav.expensesImg,homeBinding.bottomNav.profileImg,homeBinding.bottomNav.accountText,homeBinding.bottomNav.museumText,homeBinding.bottomNav.expensesText,homeBinding.bottomNav.profileText);


            Navigation.findNavController(HomeActivity.this,R.id.nav_home).navigate(R.id.accountFragment);

        });
        homeBinding.bottomNav.profileClick.setOnClickListener(view -> {

            colorText(homeBinding.bottomNav.profileImg,homeBinding.bottomNav.museumImg,homeBinding.bottomNav.expensesImg,homeBinding.bottomNav.accountImg,homeBinding.bottomNav.profileText,homeBinding.bottomNav.museumText,homeBinding.bottomNav.expensesText,homeBinding.bottomNav.accountText);

            Navigation.findNavController(HomeActivity.this,R.id.nav_home).navigate(R.id.profileFragment);

        });

    }

    private void colorText(ImageView museumImg, ImageView expensesImg, ImageView accountImg, ImageView profileImg, TextView museumText, TextView expensesText, TextView accountText, TextView profileText) {

        museumImg.setColorFilter(ContextCompat.getColor(this, R.color.app_blue_color));
        expensesImg.setColorFilter(ContextCompat.getColor(this, R.color.light_grey));
        accountImg.setColorFilter(ContextCompat.getColor(this, R.color.light_grey));
        profileImg.setColorFilter(ContextCompat.getColor(this, R.color.light_grey));

        museumText.setTextColor(getResources().getColor(R.color.app_blue_color));
        expensesText.setTextColor(getResources().getColor(R.color.light_grey));
        accountText.setTextColor(getResources().getColor(R.color.light_grey));
        profileText.setTextColor(getResources().getColor(R.color.light_grey));

    }

}