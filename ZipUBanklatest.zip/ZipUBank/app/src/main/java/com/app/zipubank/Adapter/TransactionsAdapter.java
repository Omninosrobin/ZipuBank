package com.app.zipubank.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.zipubank.R;

public class TransactionsAdapter extends RecyclerView.Adapter<TransactionsAdapter.holder> {

    @NonNull
    @Override
    public TransactionsAdapter.holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.transactions,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull TransactionsAdapter.holder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 5;
    }

    public class holder extends RecyclerView.ViewHolder {
        public holder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
