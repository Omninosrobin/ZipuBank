package com.app.zipubank.models.Receipt;

import java.io.Serializable;

public class ReceiptRoot implements Serializable {
}
