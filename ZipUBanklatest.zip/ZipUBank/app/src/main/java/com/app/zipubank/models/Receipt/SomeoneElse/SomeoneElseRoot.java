package com.app.zipubank.models.Receipt.SomeoneElse;

import com.app.zipubank.models.Receipt.SomeoneElse.SomeoneElseClass;

import java.io.Serializable;

public class SomeoneElseRoot implements Serializable {
    public String status;
    public String message;
    public Details details;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Details getDetails() {
        return details;
    }

    public void setDetails(Details details) {
        this.details = details;
    }

    public class Details{
        public String id;
        public String userId;
        public String recipientType;
        public String email;
        public String holderAccountName;
        public String bankAccopuntNumber;
        public String country;
        public String city;
        public String address;
        public String zipcode;
        public String bankCode;
        public String created;
        public String updated;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public String getRecipientType() {
            return recipientType;
        }

        public void setRecipientType(String recipientType) {
            this.recipientType = recipientType;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getHolderAccountName() {
            return holderAccountName;
        }

        public void setHolderAccountName(String holderAccountName) {
            this.holderAccountName = holderAccountName;
        }

        public String getBankAccopuntNumber() {
            return bankAccopuntNumber;
        }

        public void setBankAccopuntNumber(String bankAccopuntNumber) {
            this.bankAccopuntNumber = bankAccopuntNumber;
        }

        public String getCountry() {
            return country;
        }

        public void setCountry(String country) {
            this.country = country;
        }

        public String getCity() {
            return city;
        }

        public void setCity(String city) {
            this.city = city;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getZipcode() {
            return zipcode;
        }

        public void setZipcode(String zipcode) {
            this.zipcode = zipcode;
        }

        public String getBankCode() {
            return bankCode;
        }

        public void setBankCode(String bankCode) {
            this.bankCode = bankCode;
        }

        public String getCreated() {
            return created;
        }

        public void setCreated(String created) {
            this.created = created;
        }

        public String getUpdated() {
            return updated;
        }

        public void setUpdated(String updated) {
            this.updated = updated;
        }
    }

}
