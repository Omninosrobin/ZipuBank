package com.app.zipubank.utils;

import android.app.Application;
import android.content.Context;


public class App extends Application {

    private static Context context;
    public static AppPreferences appPreference1;
    public static Singleton singleton;

    @Override
    public void onCreate() {
        super.onCreate();
        context = getApplicationContext();
        appPreference1 = new AppPreferences(context, "zipu bank");
        singleton = new Singleton();

    }

    public static AppPreferences getAppPreference() {
        return appPreference1;
    }
    public static Singleton getSingleton() {
        return singleton;
    }

}
