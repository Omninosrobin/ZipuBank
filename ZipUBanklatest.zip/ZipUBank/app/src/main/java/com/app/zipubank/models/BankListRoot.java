package com.app.zipubank.models;

import java.io.Serializable;
import java.util.ArrayList;

public class BankListRoot implements Serializable {

    public String status;
    public String message;
    public ArrayList<BankListClass> details;


    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ArrayList<BankListClass> getDetails() {
        return details;
    }

    public void setDetails(ArrayList<BankListClass> details) {
        this.details = details;
    }
}
