package com.app.zipubank.utils;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.view.View;

import com.app.zipubank.models.RegisterModel;

import java.io.File;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

public class CommonUtil {

    public static void hideDoctorBottomNavigation(boolean b, View view) {
        if (b) {
            view.setVisibility(View.GONE);

        } else {
            view.setVisibility(View.VISIBLE);
        }

    }


    public static String getUserId() {
        if (App.getAppPreference().getStringValue(AppConstants.LOGIN_STATUS).equalsIgnoreCase("0")) {
            return App.getAppPreference().getStringValue(AppConstants.USER_ID);

        } else {

            return "";
        }
    }

    public static String getImage() {
        if (App.getAppPreference().getStringValue(AppConstants.LOGIN_STATUS).equalsIgnoreCase("0")) {
            return App.getAppPreference().getModel(AppConstants.USER_DETAILS, RegisterModel.Details.class).getProfileImage();

        } else {
            return "";
        }
    }

    public static String getName() {

        if (App.getAppPreference().getStringValue(AppConstants.LOGIN_STATUS).equalsIgnoreCase("0")) {

            return App.getAppPreference().getModel(AppConstants.USER_DETAILS, RegisterModel.Details.class).getName();

        } else {
            return "";
        }
    }

    public static String getPhoneNumber() {
        if (App.getAppPreference().getStringValue(AppConstants.LOGIN_STATUS).equalsIgnoreCase("0")) {
            return App.getAppPreference().getModel(AppConstants.USER_DETAILS, RegisterModel.Details.class).getPhoneNumber();
        } else {
            return "";
        }
    }

    private static ProgressDialog progressDialog;

    public static boolean isNetworkConnected(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null;
    }
    public static void showProgress(Activity activity, String message) {
        progressDialog = new ProgressDialog(activity);
        progressDialog.setMessage(message);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();

    }

    public static void dismissProgress() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }
    public static RequestBody getRequestBodyText(String data) {

        return RequestBody.create(MediaType.parse("text/plain"), data);

    }

    public static MultipartBody.Part  getFileData(String path, String parameter) {

        if (path != null) {

            File file = new File(path);

            final RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file);

            return MultipartBody.Part.createFormData(parameter, file.getName(), requestFile);

        } else {

            final RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), "");

            return MultipartBody.Part.createFormData(parameter, "", requestFile);

        }
    }
}
