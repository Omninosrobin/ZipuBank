package com.app.zipubank.models;

import java.util.ArrayList;

public class CountryRoot {
    public String message;
    public String success;
    public ArrayList<CountryClass> details;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }

    public ArrayList<CountryClass> getDetails() {
        return details;
    }

    public void setDetails(ArrayList<CountryClass> details) {
        this.details = details;
    }
}
