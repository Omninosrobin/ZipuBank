package com.app.zipubank.HomeActivities.Profile.Category.FamilyAccount;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.app.zipubank.R;
import com.app.zipubank.databinding.FragmentExpensesBinding;
import com.app.zipubank.databinding.FragmentViewBankDetailBinding;
import com.app.zipubank.models.UserBankDetailRoot;
import com.app.zipubank.retrofit.Mvvm;
import com.app.zipubank.utils.App;
import com.app.zipubank.utils.CommonUtil;

import java.util.ArrayList;
import java.util.List;

public class ViewBankDetail extends Fragment {
    FragmentViewBankDetailBinding bankBinding;
    List<UserBankDetailRoot.Detail> list;
    String status ;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        bankBinding = FragmentViewBankDetailBinding.inflate(getLayoutInflater());
        return bankBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        bankDetailApi();

    }

    private void setData() {
        bankBinding.accountNumber.setText(list.get(0).getiBan());
 //       bankBinding.lastName.setText(list.get(0).getLast_name());
        bankBinding.holderName.setText(list.get(0).getFirst_name());
        bankBinding.holderNumber.setText(list.get(0).getPhoneNumber());
        bankBinding.dateBirth.setText(list.get(0).getDob());
        bankBinding.cityA.setText(list.get(0).getCity());
        bankBinding.address.setText(list.get(0).getAddress());






    }

    private void bankDetailApi() {
        new Mvvm().bankDetailRootLiveData(requireActivity(),CommonUtil.getUserId()).observe(requireActivity(), new Observer<UserBankDetailRoot>() {
            @Override
            public void onChanged(UserBankDetailRoot userBankDetailRoot) {
                if (userBankDetailRoot.getSuccess().equalsIgnoreCase("1")){
                    list=userBankDetailRoot.getDetails();

                    if (list.get(0).getAccount_status().equals("0")){
                        bankBinding.pending.setVisibility(View.VISIBLE);
                        bankBinding.rejected.setVisibility(View.GONE);
                        bankBinding.approved.setVisibility(View.GONE);
                    }else if (list.get(0).getAccount_status().equals("1")){
                        bankBinding.pending.setVisibility(View.GONE);
                        bankBinding.rejected.setVisibility(View.GONE);
                        bankBinding.approved.setVisibility(View.VISIBLE);
                    }else if (list.get(0).getAccount_status().equals("2")){
                        bankBinding.pending.setVisibility(View.GONE);
                        bankBinding.rejected.setVisibility(View.VISIBLE);
                        bankBinding.approved.setVisibility(View.GONE);
                    }
                    setData();
                }else {
                    Toast.makeText(requireContext(), "Root is Null", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    @Override
    public void onResume() {

        super.onResume();
        requireActivity().findViewById(R.id.bottom_nav).setVisibility(View.VISIBLE);
    }

}