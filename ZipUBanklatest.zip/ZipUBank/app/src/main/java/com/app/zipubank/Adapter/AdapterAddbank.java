package com.app.zipubank.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.app.zipubank.R;
import com.app.zipubank.models.UserBankDetailRoot;

import java.util.ArrayList;

import retrofit2.Callback;

public class AdapterAddbank extends RecyclerView.Adapter<AdapterAddbank.holder> {
ArrayList<UserBankDetailRoot.Detail>list;
Context context;
Callback callback;

    public AdapterAddbank(ArrayList<UserBankDetailRoot.Detail> list, Context context, Callback callback) {
        this.list = list;
        this.context = context;
        this.callback = callback;
    }

    @NonNull
    @Override
    public AdapterAddbank.holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.addbank,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterAddbank.holder holder, int position) {
        holder.accNumber.setText("Account ending with" +list.get(0).getiBan().substring(18,22));


       holder.itemView.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               callback.callback(list.get(position));
           }
       });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public interface Callback {
        void  callback (UserBankDetailRoot.Detail list);
    }

    public class holder extends RecyclerView.ViewHolder {
        TextView accNumber;
        RelativeLayout bycard;
        public holder(@NonNull View itemView) {
            super(itemView);
            accNumber=itemView.findViewById(R.id.acc_number);
            bycard=itemView.findViewById(R.id.relCard);
        }
    }
}
