package com.app.zipubank.HomeActivities.Home.getStarted;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearSnapHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SnapHelper;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.app.zipubank.Adapter.TransactionsAdapter;
import com.app.zipubank.R;
import com.app.zipubank.databinding.FragmentDayBinding;

public class DayFragment extends Fragment {
    FragmentDayBinding fragmentDayBinding;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        fragmentDayBinding=FragmentDayBinding.inflate(getLayoutInflater());
        // Inflate the layout for this fragment
        return fragmentDayBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        TransactionsAdapter adapter=new TransactionsAdapter();
        fragmentDayBinding.transactionRec.setAdapter(adapter);
        SnapHelper snapHelper=new LinearSnapHelper();
        snapHelper.attachToRecyclerView(fragmentDayBinding.transactionRec);
    }
}