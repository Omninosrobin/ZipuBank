package com.app.zipubank.HomeActivities.Profile.Category.PersonalAccount;

import static android.content.ContentValues.TAG;

import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;

import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.app.zipubank.HomeActivity;
import com.app.zipubank.R;
import com.app.zipubank.databinding.FragmentEditProfileBinding;
import com.app.zipubank.models.RegisterModel;
import com.app.zipubank.retrofit.Mvvm;
import com.app.zipubank.splashScreenFragment.SplashScreen;
import com.app.zipubank.utils.App;
import com.app.zipubank.utils.AppConstants;
import com.app.zipubank.utils.CommonUtil;
import com.app.zipubank.utils.RealPathUtil;
import com.bumptech.glide.Glide;

import org.jetbrains.annotations.NotNull;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class EditProfileFragment extends Fragment {

    FragmentEditProfileBinding binding;
    private String user_name, user_gender, user_DOB, user_lat = "", user_long = "", user_image, stringPhotoPath;
    private RegisterModel details;
    private String selected_date = "";
    private int mYear, mDay, mMonth;


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       binding = FragmentEditProfileBinding.inflate(inflater, container, false);


        details = App.getAppPreference().getModel(AppConstants.USER_DETAILS, RegisterModel.class);
        Toast.makeText(requireContext(), "userid" + CommonUtil.getUserId(), Toast.LENGTH_SHORT).show();



        Log.i("abcdef",""+details.getDetails().getProfileImage());
        setData(details);
        OnClick();
        return binding.getRoot();
    }

    private void setData(RegisterModel details) {

        if (details.getDetails().getPhoneNumber() != null) {
            binding.setNumber.setText(details.getDetails().getPhoneNumber());
        } else {
            binding.setNumber.setText("123456789");
        }
        if (details.getDetails().getProfileImage() != null && details.getDetails().getProfileImage().length() != 0) {
            Glide.with(requireActivity()).load(details.getDetails().getProfileImage()).placeholder(R.drawable.user_new).into(binding.imageCircle);
        }
    }
    private void OnClick() {
        binding.getGender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Dialog dialog = new Dialog(requireContext());
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setContentView(R.layout.gender_layout);
                dialog.setCanceledOnTouchOutside(true);
                dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.getWindow().setGravity(Gravity.CENTER);
                dialog.show();
                RadioGroup radioGrp = dialog.findViewById(R.id.radioGrp);
                dialog.findViewById(R.id.done_gender).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int selectedId = radioGrp.getCheckedRadioButtonId();
                        RadioButton radioSexButton = dialog.findViewById(selectedId);
                        Toast.makeText(requireContext(), radioSexButton.getText(), Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                        binding.getGender.setText(radioSexButton.getText().toString());
                    }
                });
            }
        });
        binding.getDOB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getDOBCalender();
            }
        });

        binding.imageCircle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int permission = ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_EXTERNAL_STORAGE);
                if (permission != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2);
                } else {
                    Intent intent = new Intent(Intent.ACTION_PICK);
                    intent.setType("image/*");
                    startActivityForResult(intent, 2);
                }
            }
        });

        binding.SaveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hitApi();
            }
        });

        binding.baclImgProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requireActivity().onBackPressed();
            }
        });
    }

    private void getDOBCalender() {
        // Get Current Date
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(android.widget.DatePicker view, int i, int i1, int i2) {
                Date myDate = new Date();
                myDate.setMonth(i1);
                myDate.setYear(i - 1900);
                myDate.setDate(i2);
//                        date=dayOfMonth + "/" + (monthOfYear + 1) + "/" + year;
                SimpleDateFormat dmyFormat = new SimpleDateFormat("dd-MM-yyyy");
                // Format the date to Strings
                String mdy = dmyFormat.format(myDate);

                selected_date = mdy;
//
                binding.getDOB.setText(selected_date);
            }

        }, mYear, mMonth, mDay);

        datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        datePickerDialog.show();
    }

    private void hitApi() {

        user_name = binding.getName.getText().toString();
        user_gender = binding.getGender.getText().toString();
        user_DOB = binding.getDOB.getText().toString();
        user_long = binding.getLocation.getText().toString();

        if (user_name.isEmpty()) {
            binding.getName.setError("Enter Username");
            binding.getName.requestFocus();
        } else if (user_gender.isEmpty()) {
            binding.getDOB.setError("Enter gender");
            binding.getName.requestFocus();
        } else if (user_DOB.isEmpty()) {
            binding.getDOB.setError("Enter DOB");
            binding.getName.requestFocus();
        } else if (stringPhotoPath == null || stringPhotoPath.length() == 0) {

            Toast.makeText(requireContext(), "please select image", Toast.LENGTH_SHORT).show();

        } else if (user_long.isEmpty()) {
            binding.getLocation.setError("Enter Location");
            binding.getName.requestFocus();
        } else {
            user_long= String.valueOf(SplashScreen.longitude);
            user_lat= String.valueOf(SplashScreen.latitude);

            new Mvvm().UpdateUserProfile(requireActivity(), CommonUtil.getRequestBodyText(user_name),
                            CommonUtil.getRequestBodyText(user_gender), CommonUtil.getRequestBodyText(user_DOB),
                            CommonUtil.getRequestBodyText(user_lat), CommonUtil.getRequestBodyText(user_long),
                            CommonUtil.getRequestBodyText(CommonUtil.getUserId()), CommonUtil.getFileData(stringPhotoPath, "profileImage"))
                    .observe(requireActivity(), new Observer<RegisterModel>() {
                        @Override
                        public void onChanged(RegisterModel updateClass) {

                            Log.d(TAG, "onChanged: " + user_name);
                            Log.d(TAG, "onChanged: " + user_gender);
                            Log.d(TAG, "onChanged: " + user_DOB);
                            Log.d(TAG, "onChanged: " + user_lat);
                            Log.d(TAG, "onChanged: " + user_long);
                            Log.d(TAG, "onChanged: " + CommonUtil.getUserId());
                            Log.d(TAG, "onChanged: " + stringPhotoPath);

                            Toast.makeText(requireContext(), ""+updateClass.getDetails().getId(), Toast.LENGTH_SHORT).show();

                            if (updateClass.getSuccess().equals("1")) {
                                App.getAppPreference().saveModel(AppConstants.USER_DETAILS, updateClass);

        //                        Toast.makeText(requireContext(), "Profile Updated Successfully", Toast.LENGTH_SHORT).show();
                                Navigation.findNavController(requireActivity(), R.id.nav_home).navigate(R.id.action_editProfileFragment_to_profileFragment);
                            }
                            else {
                                Toast.makeText(requireContext(), "Update Profile Fail", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode,
                                 @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {

            if (requestCode==2){
                assert data != null;
                Uri imageUriPhotos = data.getData();
                stringPhotoPath = RealPathUtil.getRealPath(requireActivity(), imageUriPhotos);
                binding.imageCircle.setImageURI(imageUriPhotos);
            }


        }

//        else if (resultCode == ImagePicker.RESULT_ERROR) {
//
//            Toast.makeText(requireContext(), ImagePicker.Companion.getError(data), Toast.LENGTH_SHORT).show();
//
//        } else {
//            Toast.makeText(requireContext(), "Image Uploading Cancelled", Toast.LENGTH_SHORT).show();
//        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull @NotNull String[] permissions, @NonNull @NotNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }


    @Override
    public void onResume() {
        super.onResume();
        CommonUtil.hideDoctorBottomNavigation(true, HomeActivity.homeBinding.bottomNav.bottomNavigation);
    }
}