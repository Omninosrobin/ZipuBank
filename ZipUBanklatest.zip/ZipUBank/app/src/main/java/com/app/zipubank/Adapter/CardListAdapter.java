package com.app.zipubank.Adapter;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.zipubank.R;
import com.app.zipubank.models.CardDetailsClass;

import java.util.ArrayList;

import javax.security.auth.callback.Callback;

public class CardListAdapter extends RecyclerView.Adapter<CardListAdapter.Viewholder> {
    ArrayList<CardDetailsClass> cardDetailsRootArrayList;
    Callback callback;

    public interface Callback{
        void deleteList(int position);
        void selectList(RelativeLayout selectList,String tag);
    }

    public CardListAdapter(ArrayList<CardDetailsClass> cardDetailsRootArrayList, Callback callback) {
        this.cardDetailsRootArrayList = cardDetailsRootArrayList;
        this.callback = callback;
    }

    @NonNull
    @Override
    public CardListAdapter.Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Viewholder(LayoutInflater.from(parent.getContext()).inflate(R.layout.visa_item_layout,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull CardListAdapter.Viewholder holder, @SuppressLint("RecyclerView") int position) {
        holder.card_number.setText("Card ending with " +cardDetailsRootArrayList.get(position).getCardNumber().substring(12,16));
        holder.name_card.setText(cardDetailsRootArrayList.get(position).getName());

        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                callback.deleteList(position);
            }
        });
        holder.byCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                callback.selectList(holder.byCard,holder.byCard.getTag().toString());
            }
        });
    }

    @Override
    public int getItemCount() {
        return cardDetailsRootArrayList.size();
    }

    public static class Viewholder extends RecyclerView.ViewHolder {
        private TextView card_number,name_card;
        private ImageView delete;
        private RelativeLayout byCard;
        public Viewholder(@NonNull View itemView) {
            super(itemView);
            card_number = itemView.findViewById(R.id.card_number);
            name_card = itemView.findViewById(R.id.name_card);
            delete = itemView.findViewById(R.id.delete);
            byCard = itemView.findViewById(R.id.byCard);
        }
    }
}
