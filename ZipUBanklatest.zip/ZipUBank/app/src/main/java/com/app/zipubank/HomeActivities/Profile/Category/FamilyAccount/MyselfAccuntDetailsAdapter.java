package com.app.zipubank.HomeActivities.Profile.Category.FamilyAccount;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.zipubank.R;
import com.app.zipubank.models.GetMyBankDetail;
import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class MyselfAccuntDetailsAdapter extends RecyclerView.Adapter<MyselfAccuntDetailsAdapter.ViewHolder> {
    private List<GetMyBankDetail.Detail> getMyBankDetailArrayList;

    public MyselfAccuntDetailsAdapter(List<GetMyBankDetail.Detail> getMyBankDetailArrayList) {
        this.getMyBankDetailArrayList = getMyBankDetailArrayList;
    }

    @NonNull
    @Override
    public MyselfAccuntDetailsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.recepit_list,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyselfAccuntDetailsAdapter.ViewHolder holder, int position) {
        holder.recipt_name.setText(getMyBankDetailArrayList.get(position).getIban());
        holder.receipt_country.setText(getMyBankDetailArrayList.get(position).getBankName());
//        Glide.with(holder.itemView.getContext()).load(getMyBankDetailArrayList.get(position).getImage()).placeholder(R.drawable.user_new).into(holder.bank_img);
    }

    @Override
    public int getItemCount() {
        return getMyBankDetailArrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView recipt_name,receipt_country;
        private ImageView bank_img;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            recipt_name = itemView.findViewById(R.id.recipt_name);
            receipt_country = itemView.findViewById(R.id.receipt_country);
            bank_img = itemView.findViewById(R.id.bank_img);
        }
    }
}
