package com.app.zipubank.HomeActivities.Account;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearSnapHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SnapHelper;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.app.zipubank.Adapter.AddContactsAdapter;
import com.app.zipubank.Adapter.ZipUBankCard;
import com.app.zipubank.Adapter.ZipuUserContactList;
import com.app.zipubank.R;

import com.app.zipubank.databinding.FragmentAccountBinding;
import com.app.zipubank.models.AddContactsModel;
import com.app.zipubank.models.CardDetailsClass;
import com.app.zipubank.models.GetContactsList;
import com.app.zipubank.models.ShowCardDetailRoot;
import com.app.zipubank.retrofit.Mvvm;
import com.app.zipubank.utils.CommonUtil;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class AccountFragment extends Fragment implements ZipuUserContactList.Callback{
FragmentAccountBinding fragmentAccountBinding;
RecyclerView recyclerView,zipUserContacts;
RelativeLayout contacts;
TextView AddCardTxt;
    ArrayList<GetContactsList.Details.Contact> list;
String contact_num;

    ArrayList<CardDetailsClass> cardDetailsRootArrayList;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        fragmentAccountBinding = FragmentAccountBinding.inflate(getLayoutInflater());
        return fragmentAccountBinding.getRoot();

    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        findIds(view);
        checkPermission();
        CreditCard();
        apiGetContacts();


        contacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             Navigation.findNavController(requireActivity(), R.id.nav_home).navigate(R.id.addContactFragment);
            }
        });

        AddCardTxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(requireActivity(),R.id.nav_home).navigate(R.id.action_accountFragment_to_byCardPaymentFragment);
            }
        });

    }

    private void apiGetContacts() {
        new Mvvm().getContactsListLiveData(requireActivity(),CommonUtil.getUserId()).observe(requireActivity(), new Observer<GetContactsList>() {
            @Override
            public void onChanged(GetContactsList getContactsList) {

                if (getContactsList.getSuccess().equalsIgnoreCase("1")){

                    list=getContactsList.getDetails().getContacts();
              //      Toast.makeText(requireContext(), "Contacts List"+getContactsList.getMessage(), Toast.LENGTH_SHORT).show();

                    SnapHelper snapHelper=new LinearSnapHelper();
                    snapHelper.attachToRecyclerView(zipUserContacts);
                    ZipuUserContactList zipuUserContactList=new ZipuUserContactList(list,requireContext(),AccountFragment.this);
                    zipUserContacts.setAdapter(zipuUserContactList);
                }else {
                    Toast.makeText(requireContext(), "Problem in model", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }




    private void findIds(View view) {
        recyclerView=view.findViewById(R.id.recyclar);
        zipUserContacts=view.findViewById(R.id.recyclerUserContacts);
        contacts=view.findViewById(R.id.rll1);
        AddCardTxt=view.findViewById(R.id.AddCardTxt);
    }
    private void checkPermission() {

        if(ContextCompat.checkSelfPermission(requireActivity(), Manifest.permission.READ_CONTACTS)!= PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(requireActivity(), new String[]{Manifest.permission.READ_CONTACTS}, 100);
        }else{

        }
    }



    private void CreditCard() {


        new Mvvm().getCardDetailsRootLiveData(requireActivity(), CommonUtil.getUserId()).observe(requireActivity(), new Observer<ShowCardDetailRoot>() {
            @Override
            public void onChanged(ShowCardDetailRoot showCardDetailRoot) {
                if (showCardDetailRoot!=null){


                    if (showCardDetailRoot.getStatus().equalsIgnoreCase("1")){
                        cardDetailsRootArrayList = showCardDetailRoot.getDetails();
                        ZipUBankCard zipUBankCard=new ZipUBankCard(cardDetailsRootArrayList,getContext());

                        if (showCardDetailRoot.getDetails()!=null){
                            recyclerView.setAdapter(zipUBankCard);
                            fragmentAccountBinding.AddCardTxt.setVisibility(View.GONE);
                            fragmentAccountBinding.recyclar.setVisibility(View.VISIBLE);
                        }else{
                            fragmentAccountBinding.AddCardTxt.setVisibility(View.VISIBLE);

                        }
                        //   SnapHelper snapHelper = new LinearSnapHelper();

                        // on below line we are attaching this snap helper to our recycler view.
                       // snapHelper.attachToRecyclerView(recyclerView);


                    }else{
                        Toast.makeText(requireContext(), ""+showCardDetailRoot.getDetails(), Toast.LENGTH_SHORT).show();
                    }


                }else{
                    Toast.makeText(requireContext(), "Root is null", Toast.LENGTH_SHORT).show();
                }

            }
        });


    }



    @Override
    public void callback(GetContactsList.Details.Contact contact) {
        if(contact != null){
        //    Navigation.findNavController(requireActivity(),R.id.nav_home).navigate(R.id.action_accountFragment_to_internationalLocalFragment);

        }else{

        }
    }
}