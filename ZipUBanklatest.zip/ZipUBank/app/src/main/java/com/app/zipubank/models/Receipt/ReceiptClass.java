package com.app.zipubank.models.Receipt;

import java.io.Serializable;

public class ReceiptClass implements Serializable {
    private String name;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ReceiptClass(String name) {
        this.name = name;
    }
}
