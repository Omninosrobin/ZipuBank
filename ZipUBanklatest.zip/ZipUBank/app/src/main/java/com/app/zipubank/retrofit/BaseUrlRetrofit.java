package com.app.zipubank.retrofit;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BaseUrlRetrofit {

    private static Retrofit retrofit;
            //    private static final String BASE_URL = "http://evasofts.com/zipoBank/index.php/api/Zipouser/";
    //            private static final String BASE_URL_two = "http://evasofts.com/";
                private static final String BASE_URL = "http://3.20.215.255/app/zipoBank/index.php/api/Zipouser/";

    public static Retrofit getRetrofit() {

        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient okHttpClient = new OkHttpClient.Builder().connectTimeout(10, TimeUnit.MINUTES)
                .readTimeout(10, TimeUnit.MINUTES)
                .writeTimeout(10, TimeUnit.MINUTES).retryOnConnectionFailure(true).addInterceptor(loggingInterceptor).build();

        Gson gson = new GsonBuilder().setLenient().create();

        if (retrofit == null) {
            retrofit = new Retrofit.Builder().baseUrl(BASE_URL).
                    addConverterFactory(GsonConverterFactory.create(gson)).client(okHttpClient).build();
        }
        return retrofit;
    }
//
//        public static Retrofit getRetrofitTwo() {
//
//        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
//        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
//        OkHttpClient okHttpClient = new OkHttpClient.Builder().connectTimeout(10, TimeUnit.MINUTES)
//                .readTimeout(10, TimeUnit.MINUTES)
//                .writeTimeout(10, TimeUnit.MINUTES).retryOnConnectionFailure(true).addInterceptor(loggingInterceptor).build();
//
//        Gson gson = new GsonBuilder().setLenient().create();
//
//        if (retrofit == null) {
//            retrofit = new Retrofit.Builder().baseUrl(BASE_URL_two).
//                    addConverterFactory(GsonConverterFactory.create(gson)).client(okHttpClient).build();
//        }
//        return retrofit;
//    }


}
